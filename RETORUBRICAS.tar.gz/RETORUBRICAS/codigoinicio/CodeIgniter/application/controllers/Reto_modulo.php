<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reto_modulo extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Reto_modulo_model');
		$this->load->model('Reto_model');
		$this->load->model('Modulo_model');
	}




//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------




	public function index()
	{
		$datos['retos_modulo'] = $this->Reto_modulo_model->obtener_retos_modulo();
		$datos['retos'] = $this->Reto_model->obtener_retos_todos();
		$datos['modulos']=$this->Modulo_model->obtener_modulos_ciclo_centro();
		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('reto_modulo/listar_reto_modulo',$datos);
		$this->load->view('reto_modulo/nuevo_reto_modulo',$datos);
		$this->load->view('vistas_logueado/control_usuario_logueado');
		$this->load->view('footer');
	}



//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
	public function obtener_modulos_centro(){

	$idReto=$this->input->post('ID_Reto');
	$datos = $this->Reto_modulo_model->obtener_modulos_centro($idreto);

 	echo json_encode($datos->result());
	}


	public function nuevo_reto_modulo(){
	$datos = array(
		'ID_Reto' => $this->input->post('ID_Reto'),
		'ID_Modulo' => $this->input->post('ID_Modulo'),
		'ID_UAdmin' => $this->input->post('ID_UAdmin'),
	);
	$this->Reto_modulo_model->nuevo_reto_modulo($datos);
	redirect('Reto_modulo');
	}


	public function borrar(){
		$id = $this->uri->segment(3);
		$this->Reto_modulo_model->borrar_reto_modulo($id);
		redirect('Reto_modulo');
	}

}