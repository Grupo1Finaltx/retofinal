<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pdfs extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Pdfs_model');
        $this->load->model('Index_model');
        $this->load->model('Usuario_model');
        $this->load->library('Pdf');

    }
    
    public function index()
    {

    }
    public function generar() {



 

        $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('David Izcara');
        $pdf->SetTitle('Notas');
        $pdf->SetSubject('');
        $pdf->SetKeywords('TCPDF, PDF, example, test, guide');


 
        $pdf->setFooterData($tc = array(0, 64, 0), $lc = array(0, 64, 128));

// datos por defecto de cabecera, se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//relación utilizada para ajustar la conversión de los píxeles
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);


// ---------------------------------------------------------
// establecer el modo de fuente por defecto
        $pdf->setFontSubsetting(true);

// Establecer el tipo de letra
 
//Si tienes que imprimir carácteres ASCII estándar, puede utilizar las fuentes básicas como
// Helvetica para reducir el tamaño del archivo.
        $pdf->SetFont('freemono', '', 14, '', true);

// Añadir una página
// Este método tiene varias opciones, consulta la documentación para más información.
        $pdf->AddPage();

//fijar efecto de sombra en el texto
        $pdf->setTextShadow(array('enabled' => true, 'depth_w' => 0.2, 'depth_h' => 0.2, 'color' => array(196, 196, 196), 'opacity' => 1, 'blend_mode' => 'Normal'));


        //preparamos y maquetamos el contenido a crear
        $html = '';
        $html .= "<style type=text/css>";
        $html .= "td{background-color:#D9EDF7}";
        $html .= "h4{border-bottom:1px solid gray;}";
        $html .= "div >div{border:1px solid black;font-size:20px;}";
        $html .="h2+h2{color:#5C9B6B;border:1px solid black;}";
        $html .= "</style>";
        $html .= "<h2>Notas de ".$this->session->userdata('Nombre')." ".$this->session->userdata('Apellidos')."</h2>";

        $html .= "<h2>".$this->session->userdata('DESC_Centro')."<br> 2017 - 2018</h2>";


         // obtener los retos del alumno
        $retos=$this->Index_model->obtener_retos_alumno();
        if ($retos==false) {
            $this->session->set_flashdata('error_notas', 'El boletín aún no está generado.');
            redirect("Index/alumno");
        }

        foreach ($retos->result() as $reto) {

        $html .="<h4>RETO:$reto->COD_Reto</h4>";
        $html .= "<table>";

        // obtener notas de profesores, alumnos y cantidad de gente que les ha evaluado
        $datos=$this->Pdfs_model->descarga_notas($reto->ID_Reto);
        $datos2=$this->Pdfs_model->descarga_notas_2($reto->ID_Reto);
        $evaluadores_prof=$this->Pdfs_model->obtener_evaluadores(2,$reto->ID_Reto);
        $evaluadores_alum=$this->Pdfs_model->obtener_evaluadores(3,$reto->ID_Reto);


/*-----------------------------------------------------------------*/
        foreach ($datos->result() as $nota) {
            foreach ($evaluadores_prof->result() as $prof) {
                $profe_cantidad=$prof->evaluadores;
                if ($profe_cantidad==0) {
                        $profe_cantidad=1;
                }
            }
         $html .="<tr><td>Notas del profesor</td><td>".$nota->nota/($profe_cantidad*10)."/10</td><td>Valor: 70%</td></tr>";
            $notafinal_pro=($nota->nota/($profe_cantidad*10))*0.7;


        }
/*-----------------------------------------------------------------*/

        foreach ($datos2->result() as $nota) {
            foreach ($evaluadores_alum->result() as $alum) {
                $alum_cantidad=$alum->evaluadores;
                if ($alum_cantidad==0) {
                    $alum_cantidad=1;
                }
            }
            $notafinal_alu=($nota->nota/($alum_cantidad*10))*0.3;
         $html .="<tr><td>Notas de compañeros</td><td>".$nota->nota/($alum_cantidad*10)."/10</td><td>Valor: 30%</td></tr>";

        }
        $notafinal=$notafinal_pro+$notafinal_alu;
        $html .= "</table>";
        $html .= "<p>Nota final:".$notafinal."</p>";

    }
// Imprimimos el texto con writeHTMLCell()
        $pdf->writeHTMLCell($w = 0, $h = 0, $x = '', $y = '', $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = '', $autopadding = true);

// ---------------------------------------------------------
// Cerrar el documento PDF y preparamos la salida
// Este método tiene varias opciones, consulte la documentación para más información.
        $nombre_archivo = utf8_decode("Notas de ".$this->session->userdata('ID_Usuario').".pdf");
        $pdf->Output($nombre_archivo, 'I');

    }










    public function generar_profe(){
                $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('David Izcara');
        $pdf->SetTitle('Notas');
        $pdf->SetSubject('');
        $pdf->SetKeywords('TCPDF, PDF, example, test, guide');


 
        $pdf->setFooterData($tc = array(0, 64, 0), $lc = array(0, 64, 128));

// datos por defecto de cabecera, se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// se pueden modificar en el archivo tcpdf_config.php de libraries/config
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//relación utilizada para ajustar la conversión de los píxeles
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);


// ---------------------------------------------------------
// establecer el modo de fuente por defecto
        $pdf->setFontSubsetting(true);

// Establecer el tipo de letra
 
//Si tienes que imprimir carácteres ASCII estándar, puede utilizar las fuentes básicas como
// Helvetica para reducir el tamaño del archivo.
        $pdf->SetFont('freemono', '', 14, '', true);

// Añadir una página
// Este método tiene varias opciones, consulta la documentación para más información.
        $pdf->AddPage();

//fijar efecto de sombra en el texto
        $pdf->setTextShadow(array('enabled' => true, 'depth_w' => 0.2, 'depth_h' => 0.2, 'color' => array(196, 196, 196), 'opacity' => 1, 'blend_mode' => 'Normal'));






        $usuario=$this->input->post('ID_Usuario');
        // pillo los retos de un alumno
        $retos=$this->Index_model->obtener_retos_alumno_id($usuario);
        $datosusu=$this->Usuario_model->obtener_usuario($usuario);

        foreach ($datosusu->result() as $alumno) {
        //preparamos y maquetamos el contenido a crear
        $html = '';
        $html .= "<style type=text/css>";
        $html .= "td{background-color:#D9EDF7}";
        $html .= "h4{border-bottom:1px solid gray;}";
        $html .= "div >div{border:1px solid black;font-size:20px;}";
        $html .="h2+h2{color:#5C9B6B;border:1px solid black;}";
        $html .= "</style>";
        $html .= "<h2>Notas de ".$alumno->Nombre." ".$alumno->Apellidos."</h2>";
        }        
        foreach ($retos->result() as $reto) {
        $html .="<h4>RETO: ".$reto->COD_Reto."</h4>";
        $datos=$this->Pdfs_model->descarga_notas_profe($usuario,$reto->ID_Reto);
        if ($datos!=false) {
                $html .="<table>";
        $notafinal=0;
        foreach ($datos->result() as $dato) {
        $nota=$dato->Nota/10;
        $notafinal+=$nota;
        $html .="<tr><td>".$dato->DESC_Competencia."</td><td>$nota</td></tr>";
        }
        $html .="</table>";
                $html .="<p>Nota final: $notafinal</p>";

        }
        else{
            $html .="<p>Aún no tiene calificación.</p>";
        }


        }

// Imprimimos el texto con writeHTMLCell()
        $pdf->writeHTMLCell($w = 0, $h = 0, $x = '', $y = '', $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = '', $autopadding = true);

// ---------------------------------------------------------
// Cerrar el documento PDF y preparamos la salida
// Este método tiene varias opciones, consulte la documentación para más información.
        $nombre_archivo = utf8_decode("Notas de ".$this->session->userdata('ID_Usuario').".pdf");
        $pdf->Output($nombre_archivo, 'I');
    }
}