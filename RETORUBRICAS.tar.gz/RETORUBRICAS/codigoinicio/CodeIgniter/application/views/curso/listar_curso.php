

<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="" title="">Gestion de cursos</a></li>
	</ul>
</nav>

<section class="section_gestion">
<h1>Gestión de cursos</h1>
<article class="articulo_tabla">
	
<?php
		if ($cursos){
			printf('<table class="tabla" id="tabla_cursos">
				<thead>			
				<tr>
					<td>
						<label for="select_all"></label>
						<input id="select_all" type="checkbox">
					</td>
				');
			$primercurso = $cursos->result()[0];
			foreach ($primercurso as $key => $value) {
				printf('<th id="%s">
						<span>%s</span>
					</th>',$key,$key);
			}
			printf('<th>Acciones</th></tr>
			</thead>
			<tbody>');
			foreach ($cursos->result() as $curso) {
				printf('<tr>
					<th>
					<label for="select_%d"></label>
					<input id="select_%d" type="checkbox">
					</th>',$curso->ID_Curso,$curso->ID_Curso);
				foreach ($curso as $detalle) {
					printf('<td>
					<a href="Curso/editar/%s">%s</a>
					</td>',$curso->ID_Curso,$detalle);
				}
				$url = "'curso/borrar/".$curso->ID_Curso."'";
				$url_editar = "'curso/editar/".$curso->ID_Curso."'"; 
				printf('<td><input class="btn_borrar" type="button" onclick="location.href=%s" value="Borrar"><input class="btn_editar" type="button" onclick="location.href=%s" value="Editar"></td>',$url,$url_editar);
				printf('</tr>');
			}	
			//printf('<tr><td colspan="4"><button type="button" class="btn_borra_seleccionados">Borrar selecionados</button></td></tr>');
			printf('</tbody></table>');
		}
		else{
				printf('No hay Registros');
		}
		?>

</article>

<hr>
