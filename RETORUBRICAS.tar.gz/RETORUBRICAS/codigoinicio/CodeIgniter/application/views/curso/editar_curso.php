


<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="<?php echo base_url() ?>index.php/curso" title="">Gestion de cursos</a></li>		
		<li><a href="" title="">Editar curso</a></li>
	</ul>
</nav>

<article class="article_editar">
<h1>Editar Curso</h1>

<?php
$form = array(
	'name' => 'form_curso'
	);
$url = "'".base_url()."index.php/Curso'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
$COD_Curso = array(
	'name' => 'COD_Curso',
	'value' => $cursos->result()[0]->COD_Curso,
	'placeholder' => 'Código de Curso',
	'maxlength' => 9,
	'size' => 20
	);
?>

	<?php echo form_open('Curso/actualizar/'.$cursos->result()[0]->ID_Curso,$form);?>
	<?php echo form_label('Código de Curso: ','COD_Curso'); ?>
	<?php echo form_input($COD_Curso); ?>
	<br>
	<?php echo form_submit('Guardar','Guardar','class="guardar_edicion"'); ?>
	<?php echo form_button('Cancelar','Cancelar','class="cancelar_edicion"'.$js_cancel_button); ?>	
	<?php echo form_close();?>

</article>