<?php
$form = array(
	'name' => 'form_modulo'
	);
$url = "'".base_url()."index.php/Modulo'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
$COD_Modulo = array(
	'name' => 'COD_Modulo',
	'value' => $modulo->result()[0]->COD_Modulo,
	'placeholder' => 'Código de Modulo',
	'maxlength' => 10,
	'size' => 20
	);


$DESC_Modulo = array(
	'name' => 'DESC_Modulo',
	'value' => $modulo->result()[0]->DESC_Modulo,
	'placeholder' => 'Descripción de Modulo',
	'maxlength' => 100,
	'size' => 20
	);
?>



<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="<?php echo base_url() ?>index.php/modulo" title="">Gestion de modulos</a></li>		
		<li><a href="#" title="">Editar modulo</a></li>
	</ul>
</nav>


<article class="article_editar">
<h1>Editar Curso</h1>
	<?php echo form_open('Modulo/actualizar/'.$modulo->result()[0]->ID_Modulo,$form);?>
	<?php echo form_label('Código de Modulo: ','COD_Modulo'); ?>
	<?php echo form_input($COD_Modulo); ?>
	<br>

	<?php echo form_label('Descripción de Modulo: ','DESC_Modulo'); ?>
	<?php echo form_input($DESC_Modulo); ?>
	<br>
	<?php echo form_submit('Guardar','Guardar','class="guardar_edicion"'); ?>
	<?php echo form_button('Cancelar','Cancelar','class="cancelar_edicion"'.$js_cancel_button); ?>	
	<?php echo form_close();?>
</article>
