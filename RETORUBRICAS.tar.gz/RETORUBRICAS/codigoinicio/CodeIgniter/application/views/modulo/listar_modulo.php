
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="" title="">Gestion de modulos</a></li>
	</ul>
</nav>

<section id="section_modulos">

<section class="section_gestion">
	<h1>Gestión de modulos</h1>

<article class="articulo_tabla">



<?php
		if ($cursos){
			echo "<select id='select_curso' class='select_basico'>";
			echo "<option>Selecciona Curso</option>";
			foreach ($cursos->result() as $curso) {
			echo "<option value='$curso->ID_Curso'>$curso->COD_Curso</option>";
			}
			echo "</select>";
		}

?>		
		
		<select name="" id="select_ciclo" class='select_basico'>
			<option value="">Selecciona Ciclo</option>
		</select>




		<table id="tabla_modulos" class="tabla" border="1">
		<tr>
			<th>ID Modulo</th>
			<th>Código</th> 
			<th>Descripción</th>
			<th>Acción</th>

		</tr>
		</table>

</article>
<hr>
<script>
	
	$(document).ready(function(){


	$("#select_curso").change(function(){
	    $("#select_ciclo").empty();
	    $(".contenido").remove();
	    $('#select_ciclo').append($('<option>Selecciona Ciclo</option>'));

	    $.post({url: "<?php echo base_url(); ?>index.php/Modulo/ciclos_json",
	        datatype:"json",
	        data:{'ID_Curso':$("#select_curso").val()},
	        success: function(devuelto){

	        var array=JSON.parse(devuelto);
	        for (var i = 0; i < array.length; i++) {
	            $('#select_ciclo').append($('<option>', {
	                value: array[i]['ID_Ciclo'],
	                text: array[i]['COD_Ciclo']+' - '+array[i]['DESC_Ciclo']+' - '+array[i]['DESC_Centro']
	            }));
	        }
	    

	    }});
	});





	/*  Selecciona ciclo
		Elimina las filas de la anterior tabla
		hace una llamada JSON obteniendo los modulos
		hacemos visible la tabla en la que se cargaran los datos
		recorre el array añadiendo las filas. 
	*/

	$("#select_ciclo").change(function(){
		$(".contenido").remove();
		$("#tabla_modulos").css("display","block");
	    $.post({url: "<?php echo base_url(); ?>index.php/Modulo/modulos_json",
	        datatype:"json",
	        data:{'ID_Ciclo':$("#select_ciclo").val()},
	        success: function(devuelto){
	        $("#tabla_modulos").css("display","block");
	        var array=JSON.parse(devuelto);

	        for (var i = 0; i < array.length; i++) {

				var url = "Modulo/borrar_modulo/"+array[i]['ID_Modulo']; 
				var url_editar="Modulo/editar/"+array[i]['ID_Modulo'];
	            $('#tabla_modulos').append($('<tr class="contenido"><td><a href='+url_editar+'>'+array[i]['ID_Modulo']+'</a></td><td><a href='+url_editar+'>'+array[i]['COD_Modulo']+'</a></td><td><a href='+url_editar+'>'+array[i]['DESC_Modulo']+'</a></td><td><a href='+url+'><input type="button" class="btn_borrar" value="Borrar"></a><a href='+url_editar+'><input type="button" class="btn_editar" value="Editar"></a></td></tr>'));


	        }
	    

	    }});
	});


});
</script>