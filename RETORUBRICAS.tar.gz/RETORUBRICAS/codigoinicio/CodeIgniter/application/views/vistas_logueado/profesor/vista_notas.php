
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/profesor" title="">Inicio</a></li>
		<li><a href="#" title="">Obtener notas</a></li>
	</ul>
</nav>
<section id="prof_notas">
	<?php if ($notas) {
		$usuarios[0]="Selecciona alumno";
		foreach ($notas->result() as $key) {
			$usuarios[$key->ID_Usuario]=$key->Nombre.' '.$key->Apellidos;
		}
	} ?>
	<?php echo form_open('Pdfs/generar_profe') ?>
	<?php echo form_dropdown('ID_Usuario',$usuarios,'','id="select_usu_notas"'); ?>
	<?php echo form_submit('Obtener boletín','Obtener boletín') ?>
	<?php echo form_close(); ?>
</section>