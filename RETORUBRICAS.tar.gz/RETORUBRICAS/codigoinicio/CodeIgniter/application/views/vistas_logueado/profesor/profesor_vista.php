<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="#" title="">Inicio</a></li>
	</ul>
</nav>

<section id="section_profe">
	<article class="article_profe">
	<h1>Estos son los retos que podras puntuar</h1>
	<p>Estan clasificados por:</p>
	<ul>
		<li> Nombre de reto</li>
		<li> Nombre del modulo asociado</li>
		<li> Ciclo Formativo</li>
	</ul>
		

		<?php 
			$form = array(
				'name' => 'form_evaluacion'
			);
			if ($retos){
				$ID_Reto = array();
				$ID_Reto[0]="Selecciona reto";
				foreach ($retos->result() as $key) {
					$ID_Reto[$key->ID_Reto] = $key->DESC_Reto." - ".$key->DESC_Modulo." - ".$key->COD_Ciclo;
				}	
			}
			echo form_open('Evaluacion',$form);
			echo form_dropdown('ID_Reto',$ID_Reto);
			echo form_submit('Evaluar','Evaluar','id="evaluar_vista_prof"');
			echo form_close();
		?>

	</article>
	<article id="article_datos_profe">
			<h1>Datos del Profesor</h1>
	<ul>
		<li><?php echo "<b>Usuario:</b> ".$this->session->userdata('User');?></li>
		<li><?php echo "<b>Nombre:</b> ".$this->session->userdata('Nombre');?></li>
		<li><?php echo "<b>Apellidos:</b> ".$this->session->userdata('Apellidos');?></li>
		<li><?php echo "<b>Correo:</b> ".$this->session->userdata('Email');?></li>
		<li><?php echo "<b>Tipo de usuario:</b> ".$this->session->userdata('DESC_TUsuario');?></li>
		<li><?php echo "<b>Centro:</b> ".$this->session->userdata('DESC_Centro');?></li>
		<li><?php echo "<b>DNI:</b> ".$this->session->userdata('Dni');?></li>
		<?php echo form_open("Usuario/modificar_pass","name='fomuli'") ?>
		<li><input type="password" name="pass_usu_nueva" placeholder="Contraseña nueva*"></li>
		<li><?php echo form_submit('Modificar Contraseña','Modificar Contraseña');?></li>
		<?php echo form_close();?>
	</ul>
	</article>


</section>	
