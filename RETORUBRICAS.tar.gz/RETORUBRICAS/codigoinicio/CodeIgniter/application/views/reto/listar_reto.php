
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="#">Gestión de retos</a></li>		
	</ul>
</nav>

<section class="section_gestion">
<h1>Gestión de retos</h1>
<article class="articulo_tabla">
<?php if ($retoscentro) {
 ?>
<table border="1" class="tabla">
	<caption>Retos asignados</caption>
	<thead>
		<tr>
			<th>ID</th>
			<th>Código</th>
			<th>Descripción</th>
			<th>Centro</th>
			<th colspan="2">Acciones</th>
		</tr>
	</thead>
	<tbody>
	<?php 
		foreach ($retoscentro->result() as $key){
			echo'<tr>';
			echo'<td>'.$key->ID_Reto.'</td>';
			echo'<td>'.$key->COD_Reto.'</td>';
			echo'<td>'.$key->DESC_Reto.'</td>';
			echo'<td>'.$key->DESC_Centro.'</td>';

			$urleditar = "'reto/editar/".$key->ID_Reto."'"; 
			$urleliminar = "'reto/borrar/".$key->ID_Reto."'"; 
			printf('<td><input type="button" class="btn_editar" onclick="location.href=%s" value="Editar">',$urleditar);
			printf('<input type="button" class="btn_borrar" onclick="location.href=%s" value="Borrar"></td>',$urleliminar);
			echo'</tr>';
		} 
	?>
	</tbody>
</table>



<?php } ?>
<?php if ($retos) {
?>



<table border="1" class="tabla">
	<caption>Retos sin asignar</caption>
	<thead>
		<tr>
			<th>ID</th>
			<th>Código</th>
			<th>Descripción</th>
			<th colspan="2">Acciones</th>
		</tr>
	</thead>
	<tbody>
	<?php 
		foreach ($retos->result() as $key){
			echo'<tr>';
			echo'<td>'.$key->ID_Reto.'</td>';
			echo'<td>'.$key->COD_Reto.'</td>';
			echo'<td>'.$key->DESC_Reto.'</td>';

			$urleditar = "'reto/editar/".$key->ID_Reto."'"; 
			$urleliminar = "'reto/borrar/".$key->ID_Reto."'"; 
			printf('<td><input type="button" class="btn_editar" onclick="location.href=%s" value="Editar">',$urleditar);
			printf('<input type="button" class="btn_borrar" onclick="location.href=%s" value="Borrar"></td>',$urleliminar);
			echo'</tr>';
		} 
	?>
	</tbody>
</table>	


<?php }  ?>	


</article>
<hr>
