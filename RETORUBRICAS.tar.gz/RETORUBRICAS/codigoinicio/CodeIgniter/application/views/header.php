<body>
<header>
	<nav>
		<ul id="ul_index">
			<li class="principal activo"><a href="">DIL</a></li>
			<li id="li_botonmenu"><button type="button" id="boton_menu"><i class="fa fa-bars" style="font-size:24px"></i></button></li>
			<div id="div_derecha">
				<li id="google_translate_element"><a href="" title=""></a></li>
			</div>
		</ul>
	</nav>
</header>
