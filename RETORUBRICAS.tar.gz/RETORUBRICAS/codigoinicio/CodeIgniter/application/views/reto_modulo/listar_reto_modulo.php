
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="#" title="">Gestión de modulos de los retos</a></li>
	</ul>
</nav>

<section class="section_gestion">
<h1>Gestión de Modulos de los retos</h1>
<article class="articulo_tabla">
	


	<table id="tabla_reto_modulo" border="1">
		<thead>
		<tr>
			<th>ID Reto Modulo</th>
			<th>ID/Datos Reto</th> 
			<th>ID/Código Modulo</th>
			<th colspan="2">Acciones</th>
		</tr>
		</thead>
		<tbody>

<?php 

if ($retos_modulo) {
	foreach ($retos_modulo->result() as $key) {
		echo '<tr>';
		echo '<td>'.$key->ID_Reto_modulo.'</td>';
		echo '<td>'.$key->ID_Reto.' - '.$key->COD_Reto.'</td>';
		echo '<td>'.$key->ID_Modulo.' - '.$key->COD_Modulo.'</td>';
		$urleditar = "'reto_modulo/editar/".$key->ID_Reto_modulo."'"; 
		$urleliminar = "'reto_modulo/borrar/".$key->ID_Reto_modulo."'"; 
		//printf('<td><input type="button" class="btn_editar" onclick="location.href=%s" value="Editar">',$urleditar);
		printf('<td><input type="button" class="btn_borrar btn_borrar_solo" onclick="location.href=%s" value="Borrar"></td>',$urleliminar);
		echo '</tr>';
	}
}

 ?>
		</tbody>
	</table>
</article>
<hr>
