<?php 

$form = array(
	'name' => 'form_equipo_usuario',
	'id' =>'formulario_crear'

	);

if ($usuarios) {
	$ID_Usuario = array();
	$ID_Usuario[0]='Selecciona usuario';
	foreach ($usuarios->result() as $key) {
	$ID_Usuario[$key->ID_Usuario] = $key->Nombre.' '.$key->Apellidos.' - '.$key->DESC_Centro;
	}
}

if ($equipo) {
	$ID_Equipo = array();
	$ID_Equipo[0]='Selecciona Equipo';
	foreach ($equipo->result() as $key) {
	$ID_Equipo[$key->ID_Equipo] = $key->COD_Equipo.' - '.$key->DESC_Equipo.' - '.$key->COD_Reto.' '.$key->DESC_Centro;
	}
}

?>


 <h2>Añadir usuarios a un equipo</h2>
 	<?php echo form_open('Equipo_usuario/nuevo_equipo_usuario',$form);?>
	<?php echo form_label('Usuario: ','ID_Usuario'); ?>
	<?php echo form_dropdown('ID_Usuario',$ID_Usuario,0,'id="select_equipo_usuario_usuario"'); ?>
	<br>
	<?php echo form_label('Equipo: ','ID_Equìpo'); ?>
	<?php echo form_dropdown('ID_Equipo','Selecciona Equipo',1, 'id="select_equipo_usuario_equipo"'); ?>
	<br>
	<?php echo form_label('Rol: ','Rol'); ?>
	<?php echo form_input('Rol'); ?>
	<br>

	<?php echo form_submit('Crear','Crear','class="btn_crear"'); ?>
	<?php echo form_close();?>
</section>

<script>
		$("#select_equipo_usuario_usuario").change(function(){
	    $("#select_equipo_usuario_equipo").empty();
	    $.post({url: "<?php echo base_url(); ?>index.php/Equipo_usuario/obtener_equipos_centro",
	        datatype:"json",
	        data:{'ID_Usuario':$("#select_equipo_usuario_usuario").val()},
	        success: function(devuelto){
	        	
	        var array=JSON.parse(devuelto);
	        for (var i = 0; i < array.length; i++) {
	            $('#select_equipo_usuario_equipo').append($('<option>', {
	                value: array[i]['ID_Equipo'],
	                text: array[i]['COD_Equipo']+' - '+array[i]['DESC_Equipo']
	            }));
	        }
	    }});
	});


</script>