<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="" title="">Añadir usuarios a un equipo</a></li>
	</ul>
</nav>

<section class="section_gestion">
<article class="articulo_tabla">

	<h2>Añadir usuarios a un equipo</h2>



	<table id="tabla_equipo_usuario" border="1">
		<thead>
		<tr>
			<th>ID Equipo Usuario</th>
			<th>ID/Datos Equipo</th>
			<th>ID/Datos Usuario</th>
			<th>ID/Rol</th> 
			<th colspan="2">Acciones</th>
		</tr>
		</thead>
		<tbody>
			<?php 

				if ($equipo_usuario) {
					foreach ($equipo_usuario->result() as $key) {
						echo '<tr>';
						echo '<td>'.$key->ID_Equipo_Alumno.'</td>';
						echo '<td>'.$key->ID_Equipo.' - '.$key->COD_Equipo.'</td>';
						echo '<td>'.$key->ID_Usuario.' - '.$key->Nombre.' '.$key->Apellidos.'</td>';
						echo '<td>'.$key->ID_Equipo_Alumno.' - '.$key->COD_Rol.'</td>';
						
						$urleditar = "'equipo_usuario/editar/".$key->ID_Equipo_Alumno."'"; 
						$urleliminar = "'equipo_usuario/borrar/".$key->ID_Equipo_Alumno."'"; 
						printf('<td><input type="button" class="btn_editar" onclick="location.href=%s" value="Editar">',$urleditar);
						printf('<input type="button"  class="btn_borrar" onclick="location.href=%s" value="Borrar"></td>',$urleliminar);
						echo '</tr>';
					}
				}

 			?>
		</tbody>
	</table>
</article>