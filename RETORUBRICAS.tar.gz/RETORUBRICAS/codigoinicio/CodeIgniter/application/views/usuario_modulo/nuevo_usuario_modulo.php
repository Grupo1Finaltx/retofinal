<?php 

$form = array(
	'name' => 'form_usuario_modulo',
	'id'=> 'formulario_crear'
	);

if ($usuarios) {
	$ID_Usuario = array();
	$ID_Usuario[0]='Selecciona usuario';
	foreach ($usuarios->result() as $key) {
	$ID_Usuario[$key->ID_Usuario] = $key->Nombre.' '.$key->Apellidos.' - '.$key->DESC_Centro;
	}
}

 ?>


 <h2>Añadir usuarios a un modulo</h2>
 	<?php echo form_open('Usuario_modulo/nuevo_usuario_modulo',$form);?>
	<?php echo form_label('Usuario: ','ID_Usuario'); ?>
	<?php echo form_dropdown('ID_Usuario',$ID_Usuario,0,'id="select_usuario_modulo_usuario"'); ?>
	<br>
	<?php echo form_label('Modulo: ','ID_Modulo'); ?>
	<?php echo form_dropdown('ID_Modulo','Selecciona modulo',1, 'id="select_usuario_modulo_modulo"'); ?>
	<br>

	<?php echo form_submit('Crear','Crear','class="btn_crear"'); ?>
	<?php echo form_close();?>
</section>


<script>
		$("#select_usuario_modulo_usuario").change(function(){
	    $("#select_usuario_modulo_modulo").empty();

	    $.post({url: "<?php echo base_url(); ?>index.php/Usuario_modulo/obtener_modulos_centro",
	        datatype:"json",
	        data:{'ID_Usuario':$("#select_usuario_modulo_usuario").val()},
	        success: function(devuelto){

	        var array=JSON.parse(devuelto);
	        for (var i = 0; i < array.length; i++) {
	            $('#select_usuario_modulo_modulo').append($('<option>', {
	                value: array[i]['ID_Modulo'],
	                text: array[i]['COD_Ciclo']+' - '+array[i]['DESC_Centro']+' - '+array[i]['DESC_Modulo']
	            }));
	        }
	    

	    }});
	});


</script>