
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="" title="">Gestion de equipos</a></li>
	</ul>
</nav>

<section class="section_gestion">
<article class="articulo_tabla">
<table border="1" class="tabla">
	<caption>Gestion de equipos asignados</caption>
	<thead>
		<tr>
			<th>ID equipo</th>
			<th>ID reto</th>
			<th>Código de equipo</th>
			<th>Descripción de equipo</th>
			<th>Centro</th>
			<th colspan="2">Acciones</th>
		</tr>
	</thead>
<tbody>


<?php 
if ($equipos) {
	foreach ($equipos->result() as $key){
		echo '<tr>';
		echo'<td>'.$key->ID_Equipo.'</td>';
		echo'<td>'.$key->ID_Reto.'</td>';
		echo'<td>'.$key->COD_Equipo.'</td>';
		echo'<td>'.$key->DESC_Equipo.'</td>';
		echo'<td>'.$key->DESC_Centro.'</td>';
		$urleditar = "'equipo/editar/".$key->ID_Equipo."'"; 
			$urleliminar = "'equipo/borrar/".$key->ID_Equipo."'"; 
			printf('<td><input type="button" onclick="location.href=%s" class="btn_editar" value="Editar">',$urleditar);
			printf('<input type="button" onclick="location.href=%s" class="btn_borrar" value="Borrar"></td>',$urleliminar);
		echo '</tr>';
	}
}

 ?>

</tbody>
</table>



<table border="1" class="tabla">
	<caption>Gestion de equipos sin asignar a los alumnos</caption>
	<thead>
		<tr>
			<th>ID equipo</th>
			<th>ID reto</th>
			<th>Código de equipo</th>
			<th>Descripción de equipo</th>
			<th colspan="2">Acciones</th>
		</tr>
	</thead>
<tbody>


<?php 
if ($equipos_vacio) {
	foreach ($equipos_vacio->result() as $key){
		echo '<tr>';
		echo'<td>'.$key->ID_Equipo.'</td>';
		echo'<td>'.$key->ID_Reto.'</td>';
		echo'<td>'.$key->COD_Equipo.'</td>';
		echo'<td>'.$key->DESC_Equipo.'</td>';
		$urleditar = "'equipo/editar/".$key->ID_Equipo."'"; 
			$urleliminar = "'equipo/borrar/".$key->ID_Equipo."'"; 
			printf('<td><input type="button" class="btn_editar" onclick="location.href=%s" value="Editar">',$urleditar);
			printf('<input type="button" class="btn_borrar"  onclick="location.href=%s" value="Borrar"></td>',$urleliminar);
		echo '</tr>';
	}
}

 ?>

</tbody>
</table>	
</article>
<hr>