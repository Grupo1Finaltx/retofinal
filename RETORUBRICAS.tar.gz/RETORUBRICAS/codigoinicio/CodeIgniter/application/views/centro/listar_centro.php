<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="#" title="">Gestion de centros</a></li>
	</ul>
</nav>
<section class="section_gestion">
<h1>Gestión de centros</h1>
<article class="articulo_tabla">
<?php
		if ($centros){
			printf('<table class="tabla">
				<thead>			
				<tr>
					<td>
						<label for="select_all"></label>
						<input id="select_all" type="checkbox">
					</td>
				');
			$primercentro = $centros->result()[0];
			foreach ($primercentro as $key => $value) {
				printf('<th id="%s">
						<span>%s</span>
					</th>',$key,$key);
			}
			printf('<th>Acciones</th></tr>
			</thead>
			<tbody>');
			foreach ($centros->result() as $centro) {
				printf('<tr>
					<th>
					<label for="select_%d"></label>
					<input id="select_%d" type="checkbox">
					</th>',$centro->ID_Centro,$centro->ID_Centro);
				foreach ($centro as $detalle) {
					printf('<td>
					<a href="Centro/editar/%s">%s</a>
					</td>',$centro->ID_Centro,$detalle);
				}
				$url = "'centro/borrar/".$centro->ID_Centro."'"; 
				$url_editar = "'centro/editar/".$centro->ID_Centro."'"; 
				printf('<td><input type="button" class="btn_borrar" onclick="location.href=%s" value="Borrar">',$url);
				printf('<input type="button" class="btn_editar" onclick="location.href=%s" value="Editar"></td>',$url_editar);
				printf('</tr>');
			}	
			//printf('<tr><td colspan="5"><button type="button" class="btn_borra_seleccionados">Borrar selecionados</button></td></tr>');
			printf('</tbody></table>');
		}
		else{
				printf('No hay Registros');
		}
		?>		
</article>
<hr>