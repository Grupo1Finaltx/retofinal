

if ($(".trampa").text()=="?") {
	$(".trampa").css("display","none");
	$(".alerta").css("display","block");
  $( "#section_login,footer" ).animate({
    opacity: 0.1,
  }, 1500 );}

$(".btn_alerta").click(function(){
		$(".alerta").css("display","none");
		  $( "#section_login,footer" ).animate({
    opacity: 1,
  }, 1500 )

})