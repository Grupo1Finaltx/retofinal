 var base_url="http://localhost/xamppDavid/RETORUBRICAS/codigoinicio/CodeIgniter/index.php/";


// Controla el bloqueo de mayusculas en el login
$("#pass_login").keypress(function(e){
	if (innerWidth<599) {
	}
	else{
	//Obtener tecla pulsada.
	tecla=e.keyCode?e.keyCode:e.which;
	//Obtener mayus.
	mayus=e.shiftKey?e.shiftKey:((tecla==16)?true:false);
	if(((tecla>=65&&tecla<=90)&&!mayus)||((tecla>=97&&tecla<=122)&&mayus))
		$("#aviso_mayus").css("display","block");
	else $("#aviso_mayus").css("display","none");
}
});


/*Esto controla un input de la pagina de "Reto_modulo" que no se puede modificar porque es el id del profesor*/
$("#input_profe").focus(function(){
	alert("Este campo no se puede modificar");
	$("#input_profe").blur();
});




// Controlando al enviar evaluacion del alumno
document.getElementById("enviar_notas").addEventListener("click",function(e){
	e.preventDefault();
	var mediciones = new Array();
	var comprueba=true;
	mediciones[0]=$('input[name="1"]:checked').val();
	mediciones[1]=$('input[name="2"]:checked').val();
	mediciones[2]=$('input[name="3"]:checked').val();
	mediciones[3]=$('input[name="4"]:checked').val();
	mediciones[4]=$('input[name="9"]:checked').val();
	for (var i = 0; i < mediciones.length; i++) {
		if (mediciones[i]==undefined) {
			comprueba=false;
			alert("Rellena todos los campos")
			$("#enviar_notas").css("background","red")
			$("#enviar_notas").css("color","white")
			break;
		}
		else{
			comprueba=true;
		}

	}

	if (comprueba==true) {
	    $.post({url: base_url+"Evaluacion/obtener_notas",
	        datatype:"json",
	        data:{'ID_Reto':document.getElementById('reto').value,'ID_Usuario':$("#select_alumno_a_evaluar").val(),'Nota':mediciones,'ID_Evaluador':document.getElementById('evaluador').value},
	        success: function(devuelto){
	        var array=JSON.parse(devuelto);

	        alert(devuelto)
	    }});
}
});






