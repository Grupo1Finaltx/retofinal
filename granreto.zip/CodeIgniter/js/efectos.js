

// login
$( "#ayuda_login" ).click(function() {
	 $( "#ayuda_login_article" ).css("display","block");

  $( "#ayuda_login_article" ).animate({
    padding: "10px",
  }, 1000 );

  $( "#section_login" ).animate({
    opacity: 0.1,
  }, 1500 );

});


$("#cancela_ayuda_login").click(function(){
	$( "#ayuda_login_article" ).hide("slow");
	  $( "#section_login" ).animate({
    opacity: 1,
  }, 1500 );


})

// Fin login



// alumno obteniendo notas
 var base_url="http://10.9.53.104/CodeIgniter/index.php/";
$("#notas_down").click(function(e){
  e.preventDefault();
  $("section,footer").css("opacity","0.3")
  $("#cajacarga").css("opacity","1")
  $("#cajacarga").css("visibility","visible");
  $("#cajacarga p").css("visibility","visible");
    $("#cajacarga").animate({
      width: "400px"
    }, {
      duration: 200,
      easing: "linear",
      step: function(x) {
        $("#p_carga").text(Math.round(x * 100 / 400)  + "%");  
      }
    });

      location.href =base_url+"Pdfs/generar";
})



// efecto imagenes
window.onload = function() {slider_dil()};
var hoversl=0;
function slider_dil(){
    if(hoversl==0){
    $("#logodil").slideUp();
    $("#logotxurdi").slideDown();
    hoversl++;
  }

  else{
    $("#logotxurdi").fadeOut(3000);
    $("#logodil").fadeIn(3000);
    hoversl--;
  }
  slider_dil();
}


