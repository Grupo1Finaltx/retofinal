$("#COD_Centro_form").keypress(letras_no);
$("#DESC_Centro_form").keypress(numeros_no);
$("#DESC_Ciclo_form").keypress(numeros_no);
$("#DESC_Equipo_form").keypress(numeros_no);
$("#COD_Modulo_form").keypress(numeros_no);
$("#DESC_Modulo_form").keypress(numeros_no);
function letras_no(evento){
	if (isNaN(parseInt(evento.key))&& evento.keyCode!=8) {
		evento.preventDefault();
	}
}

function numeros_no(evento){
	var patron=/[a-zA-Z]/i;
	if (!patron.test(evento.key) && evento.charCode!=32) {
		evento.preventDefault();
	}
}






$("#COD_Curso_form").blur(comprobar_curso);


function comprobar_curso(evento){
	var texto=$("#COD_Curso_form").val();
	var patron=/[0-9]{4}[-][0-9]{4}/i;
	if (!patron.test(texto)) {
		$(".btn_crear").prop("disabled","disabled");
		$(".btn_crear").css("cursor","not-allowed");
		$("#COD_Curso_form").css("border-color","red");
	}
	else{
		$(".btn_crear").prop("disabled",false);
		$(".btn_crear").css("cursor","pointer");
		$("#COD_Curso_form").css("border-color","lightgreen");
	}
}
