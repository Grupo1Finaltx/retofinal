
document.getElementById("cerrar_sesion").addEventListener('click',function(e){

	if (localStorage.usuario) {
		var confimacion=confirm("¿Desea recordar el usuario?");
		if (confimacion==false) {
			localStorage.clear();
		}
	}

});
