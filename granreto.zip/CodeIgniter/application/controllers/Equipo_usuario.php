<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Equipo_usuario extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Equipo_usuario_model');
		$this->load->model('Reto_model');
		$this->load->model('Equipo_model');
		$this->load->model('Usuario_model');
	}




//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------




	public function index()
	{
		$datos['equipo_usuario'] = $this->Equipo_usuario_model->obtener_equipo_usuarios();
		$datos['equipo'] = $this->Equipo_model->obtener_equipos2();
		$datos['usuarios'] = $this->Usuario_model->obtener_usuarios();
		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('equipo_usuario/listar_equipo_usuario.php',$datos);
		$this->load->view('equipo_usuario/nuevo_equipo_usuario.php',$datos);
		$this->load->view('footer');
	}


	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------

	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['equipo_usuario']=$this->Equipo_usuario_model->obtener_equipo_usuario($datos['segmento']);
		$datos['equipo']=$this->Equipo_model->obtener_equipos();


		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('equipo_usuario/editar_equipo_usuario',$datos);
		$this->load->view('footer');
	}


	public function actualizar(){
		$datos = array(
			'ID_Equipo' => $this->input->post('ID_Equipo'),
			'COD_Rol' => $this->input->post('Rol'),
		);
		$id = $this->uri->segment(3);
		$this->Equipo_usuario_model->actualizar_equipo_usuario($id,$datos);
		redirect('Equipo_usuario');
	}


	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------


	public function obtener_equipos_centro(){

	$idusuario=$this->input->post('ID_Usuario');
	$datos = $this->Equipo_usuario_model->obtener_equipos_centro($idusuario);

 	echo json_encode($datos->result());
	}

	public function nuevo_equipo_usuario(){
		$datos = array(
			'ID_Equipo' => $this->input->post('ID_Equipo'),
			'ID_Usuario' => $this->input->post('ID_Usuario'),
			'COD_Rol' => $this->input->post('Rol'),
		);
		$this->Equipo_usuario_model->nuevo_equipo_usuario($datos);
		redirect('Equipo_usuario');
	}

	public function borrar(){
		$id = $this->uri->segment(3);
		$this->Equipo_usuario_model->borrar_equipo_usuario($id);
		redirect('Equipo_usuario');
	}

}