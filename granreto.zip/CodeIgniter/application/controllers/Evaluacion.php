<?php

//FUNCION DE ESTE CONTROLADOR
/*
	- Cargar la pagina principal.
	- Controlar el login del usuario.

*/


defined('BASEPATH') OR exit('No direct script access allowed');

class Evaluacion extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->library('email');
		$this->load->helper('email');
		$this->load->model('Evaluacion_model');	
	}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

	public function index()
	{	
		$idreto= $this->input->post('ID_Reto');
		$comprobacion=$this->Evaluacion_model->obtener_equipos_reto($idreto);
		if ($comprobacion==false) {
			$datos['error']="error";
		}
		else{
			$datos['equipos']=$comprobacion;
		}
		$this->load->view('head');
		$this->load->view('vistas_logueado/profesor/profesor_header.php');
		$this->load->view('vistas_logueado/profesor/profesor_evaluacion.php',$datos);
		$this->load->view('vistas_logueado/control_usuario_logueado.php',$datos);
		$this->load->view('footer');
	}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

	public function alumnos_grupo_json(){

		$idgrupo=$this->input->post('ID_Equipo');
		$datos=$this->Evaluacion_model->obtener_alumnos_equipo($idgrupo);

 		echo json_encode($datos->result());
	}

	/*public function eval_alumno(){
		$this->load->view('head');
		$this->load->view('vistas_logueado/profesor/profesor_header.php');
		$this->load->view('vistas_logueado/profesor/profesor_evaluando.php');
		$this->load->view('footer');
	}*/

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------


	
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

	public function evaluar(){
		$idreto=$this->input->post('ID_Reto');
		$idusuario=$this->uri->segment(3);

		$datos['alumnos']=$this->Evaluacion_model->obtener_alumnos_evaluar($idreto,$idusuario);
		$this->load->view('head');
		$this->load->view('vistas_logueado/alumno/alumno_header');
		$this->load->view('vistas_logueado/alumno/evaluando',$datos);
		$this->load->view('vistas_logueado/control_usuario_logueado');
		$this->load->view('footer');
	}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

	public function datos_para_evaluar(){
		$idtusuario=$this->input->post('ID_TUsuario');
		$competencias=$this->Evaluacion_model->datos_para_evaluar($idtusuario);

 			echo json_encode($competencias->result());
	}


	public function obtener_notas(){
		$idreto=$this->input->post('ID_Reto');
		$idusuario=$this->input->post('ID_Usuario');
		$mediciones=$this->input->post('Nota');
		$evaluador=$this->input->post('ID_Evaluador');
		$comprobar=$this->Evaluacion_model->comprobacion_ya_evaluado($idreto,$idusuario,$evaluador);
		if($comprobar==true){
			$actualizar=$this->Evaluacion_model->actualizar_nota($idreto,$idusuario,$mediciones,$evaluador);
			echo json_encode($actualizar);
		}
		else{
			$vuelta=$this->Evaluacion_model->poner_nota($idreto,$idusuario,$mediciones,$evaluador);
			echo json_encode($vuelta);
		}

	}


	public function obtener_notas_profe(){
				$idreto=$this->input->post('ID_Reto');
				$idusuario=$this->input->post('ID_Usuario');
				$mediciones=$this->input->post('Nota');
				$evaluador=$this->session->userdata('ID_Usuario');
				$comprobar=$this->Evaluacion_model->comprobacion_ya_evaluado($idreto,$idusuario,$evaluador);
				if($comprobar==true){
				$actualizar=$this->Evaluacion_model->actualizar_nota_profe($idreto,$idusuario,$mediciones,$evaluador);
				echo "nada";
				}
				else{
				$vuelta=$this->Evaluacion_model->poner_nota_profe($idreto,$idusuario,$mediciones,$evaluador);
 			echo json_encode($vuelta);
 		}
	}



	public function obtener_reto(){
		$idequipo=$this->input->post('ID_Equipo');
		$vuelta=$this->Evaluacion_model->obtener_reto($idequipo);
 		echo json_encode($vuelta->result());

	}




	public function profe_ver_notas(){
		$datos['notas']=$this->Evaluacion_model->obtener_retos_profe();
		$this->load->view('head');
		$this->load->view('vistas_logueado/profesor/profesor_header');
		$this->load->view('vistas_logueado/profesor/vista_notas',$datos);
		$this->load->view('vistas_logueado/control_usuario_logueado');

		$this->load->view('footer');
	}


}