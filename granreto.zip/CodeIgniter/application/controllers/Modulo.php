<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modulo extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Ciclo_model');
		$this->load->model('Curso_model');
		$this->load->model('Modulo_model');

	}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
	public function index()
	{
		if ($this->session->userdata('ID_TUsuario')!=1) {
			redirect("Index");
		}
		/*$datos['segmento']=$this->uri->segment(3);
		if (!$datos['segmento']){
			$datos['cursos'] = $this->Curso_model->obtener_cursos();
		}else{
			$datos['cursos'] = $this->Cursos_model->obtener_cursos($datos['segmento']);
		}*/
		
		// Primero listamos los cursos
		$datos['cursos'] = $this->Curso_model->obtener_cursos();
		$datos['cicloscentros']=$this->Modulo_model->obtener_cicloscentros();
		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('vistas_logueado/control_usuario_logueado');

		$this->load->view('modulo/listar_modulo',$datos);
		$this->load->view('modulo/nuevo_modulo',$datos);
		$this->load->view('footer');

	}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------



	public function nuevo_modulo(){
		$datos = array(
			'COD_Modulo' => $this->input->post('COD_Modulo'),
			'DESC_Modulo' => $this->input->post('DESC_Modulo'),
			'ID_Ciclo'	=> $this->input->post('ID_Ciclo'),
		);
		$this->Modulo_model->nuevo_modulo($datos);

	}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------


	public function borrar_modulo(){
		$id = $this->uri->segment(3);
		$this->Modulo_model->borrar_modulo($id);
		redirect('Modulo');
	}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------


	public function editar(){
		$datos['segmento']=$this->uri->segment(3);
		$datos['modulo']=$this->Modulo_model->obtener_modulo($datos['segmento']);
		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('modulo/editar_modulo',$datos);
		$this->load->view('vistas_logueado/control_usuario_logueado');

		$this->load->view('footer');
	}

	public function actualizar(){
		$datos = array(
			'COD_Modulo' => $this->input->post('COD_Modulo'),
			'DESC_Modulo' => $this->input->post('DESC_Modulo')
		);
		$id = $this->uri->segment(3);
		$this->Modulo_model->actualizar_modulo($id,$datos);
		redirect('Modulo');
	}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------



	// Esta funcion utiliza Ajax para obtener los ciclos
	 public function ciclos_json()
	 {		
	 		$idcurso=$this->input->post('ID_Curso');
	 		$ciclos=$this->Modulo_model->obtener_ciclos($idcurso);

 			echo json_encode($ciclos->result());
	 }



	 public function modulos_json()
	 {		
	 		$idciclo=$this->input->post('ID_Ciclo');
	 		$modulos=$this->Modulo_model->obtener_modulos($idciclo);

 			echo json_encode($modulos->result());
	 }


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------



}