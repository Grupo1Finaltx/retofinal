<?php 

if ($datos) {
	foreach ($datos->result() as $key) {
		echo "Hola <b>$key->Nombre</b>, Rellena el formulario para cambiar la contraseña.";

	echo form_open('Index/recuperar_final/'.$key->ID_Usuario);
	echo form_password('contrasena','','placeholder="ssss"');
	echo form_submit('Modificar','Modificar');
	echo form_close();
	}
}

 ?>