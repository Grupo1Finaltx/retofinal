<?php
$form = array(
	'name' => 'form_equipo'
	);
$url = "'".base_url()."index.php/Equipo'";
$js_cancel_button = 'onClick="location.href='.$url.'"';

$COD_Equipo = array(
	'name' => 'COD_Equipo',
	'value' => $equipos->result()[0]->COD_Equipo,
	'placeholder' => 'Código de Equipo',
	'maxlength' => 10,
	'size' => 20
	);

$DESC_Equipo = array(
	'name' => 'DESC_Equipo',
	'value' => $equipos->result()[0]->DESC_Equipo,
	'placeholder' => 'Descripción de Equipo',
	'maxlength' => 50,
	'size' => 20
	);
?>
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="<?php echo base_url() ?>index.php/equipo" title="">Gestion de equipos</a></li>		
		<li><a href="" title="">Editar Equipo</a></li>
	</ul>
</nav>

<article class="article_editar">
<h1>Editar Equipo</h1>

	<?php echo form_open('Equipo/actualizar/'.$equipos->result()[0]->ID_Equipo,$form);?>
	<?php echo form_label('Código de Equipo: ','COD_Equipo'); ?>
	<?php echo form_input($COD_Equipo); ?>
	<br>
	<?php echo form_label('Descripción de Equipo: ','DESC_Equipo'); ?>
	<?php echo form_input($DESC_Equipo); ?>
	<br>
	<?php echo form_submit('Guardar','Guardar','class="guardar_edicion"'); ?>
	<?php echo form_button('Cancelar','Cancelar','class="cancelar_edicion"'.$js_cancel_button); ?>	
	<?php echo form_close();?>
</article>
</section>
