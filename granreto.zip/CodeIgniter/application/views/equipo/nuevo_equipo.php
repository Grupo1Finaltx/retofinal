<?php
$form = array(
	'name' => 'form_equipo',
	'id' =>'formulario_crear'

	);
$COD_Equipo = array(
	'name' => 'COD_Equipo',
	'placeholder' => 'Código de Equipo',
	'maxlength' => 10,
	'size' => 20
	);

$DESC_Equipo = array(
	'name' => 'DESC_Equipo',
	'placeholder' => 'Descripción de Equipo',
	'maxlength' => 50,
	'size' => 20,
	'id' => 'DESC_Equipo_form'
	);


if ($retos) {
	$ID_Reto = array();
	foreach ($retos->result() as $key) {
		$ID_Reto[$key->ID_Reto] = $key->COD_Reto.' - '.$key->DESC_Reto.' - '.$key->DESC_Centro;
	}
} 

?>
<h2>Crear un equipo</h2>

	<?php echo form_open('Equipo/nuevo_Equipo',$form);?>
	<?php echo form_label('Código de Equipo: ','COD_Equipo'); ?>
	<?php echo form_input($COD_Equipo); ?>
	<br>
	<?php echo form_label('Descripción de Equipo: ','DESC_Equipo'); ?>
	<?php echo form_input($DESC_Equipo); ?>
	<br>
	<?php echo form_label('Selecciona reto: ','ID_Reto'); ?>
	<?php echo form_dropdown('ID_Reto', $ID_Reto,1); ?>
	<br>
	<?php echo form_submit('Crear','Crear','class="btn_crear"'); ?>
	<?php echo form_close();?>
</section>
