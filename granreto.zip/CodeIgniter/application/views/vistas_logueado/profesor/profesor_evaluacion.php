
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/profesor" title="">Inicio</a></li>
		<li><a href="#" title="">Evaluación</a></li>
	</ul>
</nav>
<section>
	<?php 
		$form = array(
			'name' => 'form_eleccion_grupo'
		);
		if (isset($equipos)) {
			$ID_Equipo = array();
			$ID_Equipo[0]="Selecciona un equipo para ver alumnos";

			foreach ($equipos->result() as $key) {
				$ID_Equipo[$key->ID_Equipo]=$key->COD_Equipo;
			}


		echo form_open('Evaluacion',$form);
		echo form_dropdown('ID_Equipo',$ID_Equipo,'', 'id="select_equipo"');
		echo form_close();


$oculto = array(
        'type'  => 'hidden',
        'name'  => 'ID_Reto',
        'id'    => 'reto',
        'value' => $equipos->result()[0]->ID_Reto,
);

	echo  form_input($oculto);
}
else{
	echo "<p>No hay equipos en este reto.</p>";
}


	?>
<select id="select_alumnos">
<option>Selecciona alumno</option>
</select>



</section>

<section id="competencias_section">
		
<article id="articulo_form_evaluacion">

<table id="tabla_competencias">

</table>

<input type="submit" name="enviar" value="enviar valoracion" id="enviar_notas_admin">
</article>
</section>