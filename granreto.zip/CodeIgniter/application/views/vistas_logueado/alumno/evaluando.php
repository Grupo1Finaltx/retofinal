

<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/alumno" title="">Inicio</a></li>
		<li><a href="#" title="">Evaluación</a></li>
	</ul>
</nav>

<section id="alumno_evaluador">
	<h1>Evalua tu participación y la de tus compañeros en el reto</h1>
<?php 

if ($alumnos) {
	$alumnos_eval[0]="Selecciona alumno";
	foreach ($alumnos->result() as $key) {
		$alumnos_eval[$key->ID_Usuario]=$key->Apellidos.', '.$key->Nombre;
	}
}


$oculto = array(
        'type'  => 'hidden',
        'name'  => 'ID_Reto',
        'id'    => 'reto',
        'value' => $alumnos->result()[0]->ID_Reto,
);
	echo form_label('Usuario a evaluar: ','ID_Usuario');
 	echo form_dropdown('ID_Usuario',$alumnos_eval,'','id="select_alumno_a_evaluar"'); 

	echo  form_input($oculto);



?>
<article id="article_elementos_hidden">
	
</article>
<article id="articulo_form_evaluacion">
<form action="Evaluacion/obtener_notas" method="POST" name="form_notas">

<table id="tabla_competencias">

</table>

<input type="submit" name="enviar" value="enviar valoracion" id="enviar_notas">
</form>
</article>
</section>

<script>
		$("#select_alumno_a_evaluar").change(function(){
			$("#article_elementos_hidden input").remove();
			$("#article_elementos_hidden").append("<input type='hidden' value='<?php echo $this->session->userdata('ID_Usuario')?>' id='evaluador'></input>");
			$(".tr_eliminar").remove();

	    $.post({url: "<?php echo base_url(); ?>index.php/Evaluacion/datos_para_evaluar",
	        datatype:"json",
	        data:{'ID_TUsuario':'3'},
	        success: function(devuelto){
	        var array=JSON.parse(devuelto);
	   


	        for (var i = 0; i < array.length; i++) {

	        var mal=array[i]['Porcentaje']*0.25;
	        var regular=array[i]['Porcentaje']*0.5;
	        var bien=array[i]['Porcentaje']*0.75;
	        var excelente=array[i]['Porcentaje'];

	        	$("#tabla_competencias").append("<tr class='tr_eliminar'><th colspan='3'>"+array[i]['DESC_Competencia']+"</th><td>"+array[i]['Mal']+"</td><td>"+array[i]['Regular']+"</td><td>"+array[i]['Bien']+"</td><td>"+array[i]['Excelente']+"</td></tr>");

	        	$("#tabla_competencias").append("<tr class='tr_eliminar'><td colspan='3'>Valoración</td><td class='celda_mal'><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+mal+"'>Mal</input></td><td class='celda_reg'><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+regular+"'>Regular</input></td><td class='celda_bien'><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+bien+"'>Bien</input></td><td class='celda_ex'><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+excelente+"'>Excelente</input></td></tr>");

	        	$("#enviar_notas").css("visibility","visible");
	        }
	    

	    }});
	});








</script>