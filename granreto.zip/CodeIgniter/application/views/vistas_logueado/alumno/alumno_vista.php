
<!-- En este archivo se muestra el panel de usuario donde prodra elegir el reto y tendra la opcion de seleccionar autoevaluarse o evaluar la participacion en el reto de sus compañeros de grupo, estas dos opciones te mandaran a otra vista en la que se llevara a cabo dicha accion -->

<?php 


$form = array(
	'name' => 'form_modulo',
	'id'   => 'form_reto_a_evaluar'
	);

if(isset($retos_usuario)){
	foreach ($retos_usuario->result() as $reto) {
		$reto_enviar[$reto->ID_Reto]=$reto->COD_Reto.','. $reto->DESC_Reto;
	}


/*if($notas){
	$notafinal=0;
	foreach ($notas->result() as $nota) {
		$notafinal=$notafinal+$nota->Nota;
	}
				echo $notafinal*10/100;

}*/

 ?>

<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="#" title="">Inicio</a></li>
	</ul>
</nav>
<section id="section_usuario">

<article class="articulo_alumno">
	<h1>Selección de Reto</h1>


	<?php echo form_open('Evaluacion/evaluar/'.$this->session->userdata('ID_Usuario'),$form);?>
	<?php 	echo form_dropdown('ID_Reto',$reto_enviar,'', 'id="seleccion_reto_alumno"'); ?>
	<ul>
		<li><?php echo form_submit('Evaluar','Evaluar','id="autoeval"');?>
</li>
	</ul>

	<?php echo form_close();?>

</article>

<?php } 

else{
	echo "<article class='articulo_alumno'>";
	echo "Aún no tienes retos asignados.";
	echo "</article>";
}

?>

<article class="articulo_alumno">
	<h1>Datos del Alumno</h1>
	<ul>
		<li><?php echo "<b>Usuario:</b> ".$this->session->userdata('User');?></li>
		<li><?php echo "<b>Nombre:</b> ".$this->session->userdata('Nombre');?></li>
		<li><?php echo "<b>Apellidos:</b> ".$this->session->userdata('Apellidos');?></li>
		<li><?php echo "<b>Correo:</b> ".$this->session->userdata('Email');?></li>
		<li><?php echo "<b>Tipo de usuario:</b> ".$this->session->userdata('DESC_TUsuario');?></li>
		<li><?php echo "<b>Centro:</b> ".$this->session->userdata('DESC_Centro');?></li>
		<li><?php echo "<b>DNI:</b> ".$this->session->userdata('Dni');?></li>
		<?php echo form_open("Usuario/modificar_pass","name='fomuli'") ?>
		<li><input type="password" name="pass_usu_nueva" placeholder="Contraseña nueva*"></li>
		<li><?php echo form_submit('Modificar Contraseña','Modificar Contraseña');?></li>
		<?php echo form_close();?>
	</ul>

</article>



</section>
