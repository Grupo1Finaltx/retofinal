<?php 

$form = array(
	'name' => 'form_reto_modulo',
	'id' =>'formulario_crear'

	);

if ($retos) {
	$ID_Reto = array();
	$ID_Reto[0]='Selecciona reto';
	foreach ($retos->result() as $key) {
	$ID_Reto[$key->ID_Reto] = $key->COD_Reto.' '.$key->DESC_Reto;
	// - '.$key->DESC_Centro;
	}
}


if ($modulos) {
	$ID_Modulo = array();
	$ID_Modulo[0]='Selecciona modulo';
	foreach ($modulos->result() as $key) {
	$ID_Modulo[$key->ID_Modulo] = $key->DESC_Centro.' - '.$key->COD_Modulo.' - '.$key->COD_Ciclo;
	}
}



$data = array(
        'type'  => 'text',
        'name'  => 'ID_UAdmin',
        'placeholder' => 'Profesor',
        'id' => 'input_profe',
);

 ?>


 <h2>Añadir retos a un modulo</h2>
 	<?php echo form_open('Reto_modulo/nuevo_reto_modulo',$form);?>
	<?php echo form_label('Reto: ','ID_Reto'); ?>
	<?php echo form_dropdown('ID_Reto',$ID_Reto,0,'id="select_reto_modulo_reto"'); ?>
	<br>
	<?php echo form_label('Modulo: ','ID_Modulo'); ?>
	<?php echo form_dropdown('ID_Modulo',$ID_Modulo,0, 'id="select_reto_modulo_modulo"'); ?>
	<br>
	<?php echo form_input($data); ?>
	<?php echo form_submit('Crear','Crear','class="btn_crear"'); ?>
	<?php echo form_close();?>

</section>

<script>
		$("#select_reto_modulo_modulo").change(function(){

	    $.post({url: "<?php echo base_url(); ?>index.php/Usuario/obtener_admin",
	        datatype:"json",
	        data:{'ID_Modulo':$("#select_reto_modulo_modulo").val()},
	        success: function(devuelto){
	        	alert(devuelto)
	        var array=JSON.parse(devuelto);
	        for (var i = 0; i < array.length; i++) {
	            $('#input_profe').val(array[i]['ID_Usuario']);
	        }
	    

	    }});
	});

</script>