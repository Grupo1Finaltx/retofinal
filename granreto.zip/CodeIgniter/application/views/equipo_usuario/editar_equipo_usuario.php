<?php
	$form = array(
		'name' => 'form_equipo_usuario'
		);
	$url = "'".base_url()."index.php/Equipo_usuario'";
	$js_cancel_button = 'onClick="location.href='.$url.'"';

	//tiene qu ecoger el nombre de la tabla usuarios a traves del id que se da en la consulta
	$Nombre =  $equipo_usuario->result()[0]->Nombre;
	$Apellidos = $equipo_usuario->result()[0]->Apellidos;


	if ($equipo){
		$ID_Equipo = array();
		foreach ($equipo->result() as $equipo) {
			$ID_Equipo[$equipo->ID_Equipo] = $equipo->COD_Equipo;
		}	
	}

	$Rol = array(
	'name' => 'Rol',
	'value' => $equipo_usuario->result()[0]->COD_Rol,
	'placeholder' => 'Rol',
	'maxlength' => 50,
	'size' => 10
	);

?>
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="<?php echo base_url() ?>index.php/equipo_usuario" title="">Añadir usuarios a un equipo</a></li>		
		<li><a href="" title="">Editar Equipo Usuario</a></li>
	</ul>
</nav>

<article class="article_editar">
	<?php echo form_open('Equipo_usuario/actualizar/'.$equipo_usuario->result()[0]->ID_Equipo_Alumno,$form);?>
	<?php echo form_label($Nombre); ?>
	<?php echo form_label($Apellidos); ?><br><br>
	<?php echo form_label('Equipo: '); ?>
	<?php echo form_dropdown('ID_Equipo', $ID_Equipo, $equipo_usuario->result()[0]->ID_Equipo); ?><br>
	<?php echo form_label('Rol: '); ?>
	<?php echo form_input($Rol); ?><br>


	<?php echo form_submit('Guardar','Guardar','class="guardar_edicion"'); ?>
	<?php echo form_button('Cancelar','Cancelar','class="cancelar_edicion"'.$js_cancel_button); ?>
	<?php echo form_close();?>
	
</article>