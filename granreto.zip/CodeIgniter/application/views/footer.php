

<footer>
<section id="section_footer">
		<article id="terminos">
		<ul>
			<li><a href="http://www.fptxurdinaga.hezkuntza.net/web/Guest" target="_blank" title="">CIFP Txurdinaga</a></li>
			<li><a href="http://www.euskadi.eus/gobierno-vasco/departamento-educacion/" target="_blank" title="">Gobierno Vasco</a></li>
			<li><a href="http://www.once.es/new/servicios-especializados-en-discapacidad-visual/accesibilidad" title="" target="_blank" >Accesibilidad</a></li>
		</ul>
	</article>

	<article id="logo"><br>
		<img src="<?php echo base_url(); ?>imagenes/dil.png" alt=""  class="logo1" id="logodil">		
		<img src="<?php echo base_url(); ?>imagenes/txurdi.png" alt=""  class="logo1" id="logotxurdi">
	</article>

	<article id="info">
		<ul>
			<li style="color:red; font-weight: bold;"><?php	setlocale(LC_TIME,"es_ES"); echo strftime("Hoy es %A %d de %B de %Y"); ?></li>
			<li><a href="" title="">Terminos y Condiciones (PROXIMAMENTE)</a></li>
			<li><a href="" title="">Politica de privacidad (PROXIMAMENTE)</a></li>
			<li><a href="" title="">Politica de Cookies (PROXIMAMENTE)             </a></li>
			<li></li>
		</ul>
	</article>
</section>


<section id="linea_footer">
	<p>© CopyRight 2017-2018 ®David Izcara ®Izaskun Boada ®Leire Gomez</p>
</section>

</footer>
</body>
</html>




<!-- LINKS DE SCRIPTS AQUI QUE SI SE PONEN EN EL HEAD NO FUNCIONAN -->
<script src="<?php echo base_url(); ?>js/funciones.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/cerrar_sesion.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/efectos.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/form_controlador.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/funciones_admin.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/alerta.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/control_notas_profe.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>js/form_generales.js" type="text/javascript"></script>
