<?php
$form = array(
	'name' => 'form_modulo',
	'id' =>'formulario_crear'

	);
$COD_Modulo = array(
	'name' => 'COD_Modulo',
	'placeholder' => 'Código de modulo',
	'maxlength' => 10,
	'size' => 20,
	'id' => 'COD_Modulo_form'
	);

$DESC_Modulo = array(
	'name' => 'DESC_Modulo',
	'placeholder' => 'Descripción de modulo',
	'maxlength' => 100,
	'size' => 20,
	'id' => 'DESC_Modulo_form'
	);


if ($cicloscentros) {
	$ID_Ciclo = array();
	foreach ($cicloscentros->result() as $key) {
		$ID_Ciclo[$key->ID_Ciclo] = $key->COD_Curso.' - '.$key->COD_Ciclo.' - '.$key->DESC_Centro;
	}
} 
?>
<h2>Crea un modulo</h2>
	<?php echo form_open('Modulo/nuevo_modulo',$form);?>
	<?php echo form_label('Código de modulo: ','COD_Modulo'); ?>
	<?php echo form_input($COD_Modulo); ?>
	<br>
	<?php echo form_label('Descripción de modulo: ','DESC_Modulo'); ?>
	<?php echo form_input($DESC_Modulo); ?>
	<br>
	<?php echo form_label('Selecciona ciclo: ','ID_Ciclo'); ?>
	<?php echo form_dropdown('ID_Ciclo', $ID_Ciclo,1); ?>
	<br>
	<?php echo form_submit('Crear','Crear','class="btn_crear"'); ?>
	<?php echo form_close();?>
</section>
