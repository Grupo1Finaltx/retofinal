<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reto_modulo_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
public function obtener_retos_modulo(){

		$sql="SELECT * FROM Reto_Modulo rm, Reto r, Modulo m WHERE r.ID_Reto=rm.ID_Reto AND m.ID_Modulo=rm.ID_Modulo";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
}


public function nuevo_reto_modulo($datos){

		$this->db->insert('Reto_Modulo',$datos);

}




}


?>