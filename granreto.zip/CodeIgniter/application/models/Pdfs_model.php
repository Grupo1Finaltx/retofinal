<?php 
class Pdfs_model extends CI_Model
{
 function __construct()
 {
 parent::__construct();
 }

public function descarga_notas($idreto){
  $sql="SELECT SUM(`Notas`.`Nota`) nota, `Reto`.`COD_Reto`, `Usuario`.`ID_TUsuario` FROM `Usuario` LEFT JOIN `Notas` ON `Notas`.`ID_Evaluador` = `Usuario`.`ID_Usuario` LEFT JOIN `Reto` ON `Notas`.`ID_Reto` = `Reto`.`ID_Reto` WHERE Notas.ID_Usuario='".$this->session->userdata('ID_Usuario')."' AND Reto.ID_Reto=$idreto AND Usuario.ID_TUsuario=2";

  $query = $this->db->query($sql);
  if ($query->num_rows() > 0){
      return $query;
  }else{
      return false;
  }
}


public function descarga_notas_2($idreto){
  $sql="SELECT SUM(`Notas`.`Nota`) nota, `Reto`.`COD_Reto`, `Usuario`.`ID_TUsuario` FROM `Usuario` LEFT JOIN `Notas` ON `Notas`.`ID_Evaluador` = `Usuario`.`ID_Usuario` LEFT JOIN `Reto` ON `Notas`.`ID_Reto` = `Reto`.`ID_Reto` WHERE Notas.ID_Usuario='".$this->session->userdata('ID_Usuario')."' AND Reto.ID_Reto=$idreto AND Usuario.ID_TUsuario=3";

  $query = $this->db->query($sql);
  if ($query->num_rows() > 0){
      return $query;
  }else{
      return false;
  }
}


public function descarga_notas_profe($usu,$reto){
  $sql="SELECT * FROM Competencia c,Notas n, Usuario u WHERE ID_Evaluador='".$this->session->userdata('ID_Usuario')."' AND n.ID_Competencia=c.ID_Competencia AND n.ID_Usuario=$usu AND u.ID_Usuario=n.ID_Usuario AND n.ID_Reto=$reto";
  $query = $this->db->query($sql);
  if ($query->num_rows() > 0){
      return $query;
  }else{
      return false;
  }
}
  

public function obtener_evaluadores($tusuario,$idreto){
  $sql="SELECT COUNT(DISTINCT ID_Evaluador) evaluadores FROM Notas,Usuario WHERE Notas.ID_Usuario='".$this->session->userdata('ID_Usuario')."' AND ID_Evaluador=Usuario.ID_Usuario AND Usuario.ID_TUsuario=$tusuario AND Notas.ID_Reto=$idreto";
    $query = $this->db->query($sql);
  if ($query->num_rows() > 0){
      return $query;
  }else{
      return false;
  }
}




}
