<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Equipo_usuario_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------



	public function obtener_equipo_usuarios(){
		$sql="SELECT * FROM Usuario u, Equipo e, Equipo_Usuario eu , Reto r WHERE u.ID_Usuario = eu.ID_Usuario AND e.ID_Equipo = eu.ID_Equipo AND e.ID_Reto = r.ID_Reto ";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------



	public function obtener_equipo_usuario($id){
		$sql="SELECT eu.ID_Equipo_Alumno, u.ID_Usuario, u.Nombre, u.Apellidos, r.ID_Reto, r.COD_Reto, e.ID_Equipo, e.COD_Equipo, eu.COD_Rol  FROM Usuario u, Equipo e, Equipo_Usuario eu , Reto r WHERE u.ID_Usuario = eu.ID_Usuario AND e.ID_Equipo = eu.ID_Equipo AND e.ID_Reto = r.ID_Reto AND eu.ID_Equipo_Alumno = $id";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}

	public function obtener_equipos_centro($id){
		$sql="SELECT DISTINCT ID_Equipo, e.ID_Reto, COD_Equipo, DESC_Equipo FROM Equipo e, Reto r, Reto_Modulo rm, Modulo m, Ciclo ci, Centro ce, Usuario u WHERE e.ID_Reto = r.ID_Reto AND r.ID_Reto = rm.ID_Reto AND rm.ID_Modulo = m.ID_Modulo AND m.ID_Ciclo = ci.ID_Ciclo AND ci.ID_Centro = ce.ID_Centro AND ce.ID_Centro = u.ID_Centro AND u.ID_Centro = (SELECT ID_Centro FROM Usuario u WHERE u.ID_Usuario = $id)";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0){
			return $query;
		}else{
			return false;
		}
	}



//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------




	public function borrar_equipo_usuario($id){
	$this->db->where('ID_Equipo_Alumno',$id);
	$this->db->delete('Equipo_Usuario');
	}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------


	public function actualizar_equipo_usuario($id,$datos){

		$this->db->where('ID_Equipo_Alumno',$id);
		$this->db->update('Equipo_Usuario', $datos);
	}	

	public function nuevo_equipo_usuario($datos){
		$this->db->insert('Equipo_Usuario',$datos);
	}
}


?>