<?php
// aqui solo se ponen funciones
function obtener_fecha(){
	$fecha= getdate();

//MES
	if ($fecha['mon']==1) {
		$mes="Enero";
	}
	if ($fecha['mon']==2) {
		$mes="Febrero";
	}
	if ($fecha['mon']==3) {
		$mes="Marzo";
	}
	if ($fecha['mon']==4) {
		$mes="Abril";
	}
	if ($fecha['mon']==5) {
		$mes="Mayo";
	}
	if ($fecha['mon']==6) {
		$mes="Junio";
	}
	if ($fecha['mon']==7) {
		$mes="Julio";
	}
	if ($fecha['mon']==8) {
		$mes="Agosto";
	}
	if ($fecha['mon']==9) {
		$mes="Septiembre";
	}
	if ($fecha['mon']==10) {
		$mes="Octubre";
	}
	if ($fecha['mon']==11) {
		$mes="Noviembre";
	}
	if ($fecha['mon']==11) {
		$mes="Diciembre";
	}



// DIA
	if ($fecha['wday']==1) {
		$dia="Lunes";
	}
	if ($fecha['wday']==2) {
		$dia="Martes";
	}
	if ($fecha['wday']==3) {
		$dia="Miercoles";
	}
	if ($fecha['wday']==4) {
		$dia="Jueves";
	}
	if ($fecha['wday']==5) {
		$dia="Viernes";
	}
	if ($fecha['wday']==6) {
		$dia="Sabado";
	}
	if ($fecha['wday']==7) {
		$dia="Domingo";
	}

	$año=$fecha['year'];
	$hora=$fecha['hours'];
	$minutos=$fecha['minutes'];
	$segundos=$fecha['seconds'];
	$diames=$fecha['mday'];
	return "El $diames de $mes de $año a las $hora:$minutos:$segundos ($dia)";
}







function obtener_ip_cliente() {

return $_SERVER['REMOTE_ADDR'];

}




function obtener_navegador(){
	$navegador = $_SERVER['HTTP_USER_AGENT'];
	return $navegador;
}

?>