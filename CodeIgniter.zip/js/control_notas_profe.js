	var base_url="http://localhost/CodeIgniter/index.php/";

	$("#select_alumnos").change(function(){
		$(".tr_eliminar").remove();
	    $.post({url: base_url+"Evaluacion/datos_para_evaluar",
	        datatype:"json",
	        data:{'ID_TUsuario':'2'},
	        success: function(devuelto){
	        var array=JSON.parse(devuelto);
	        for (var i = 0; i < array.length; i++) {
	        var mal=array[i]['Porcentaje']*0.25;
	        var bien=array[i]['Porcentaje']*0.5;
	        var regular=array[i]['Porcentaje']*0.75;
	        var excelente=array[i]['Porcentaje'];

	        $("#tabla_competencias").append("<tr class='tr_eliminar'><th colspan='3'>"+array[i]['DESC_Competencia']+"</th><td>"+array[i]['Mal']+"</td><td>"+array[i]['Regular']+"</td><td>"+array[i]['Bien']+"</td><td>"+array[i]['Excelente']+"</td></tr>");
	        

	    	$("#tabla_competencias").append("<tr class='tr_eliminar'><td colspan='3'>Valoración</td><td><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+mal+"'>1</input></td><td><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+bien+"'>2</input></td><td><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+regular+"'>3</input></td><td><input type='radio' name='"+array[i]['ID_Competencia']+"' value='"+excelente+"'>4</input></td></tr>");

	    	     $("#enviar_notas_admin").css("visibility","visible");

	        }

    document.getElementById("tabla_competencias").rows['8'].cells['3'].remove();
    document.getElementById("tabla_competencias").rows['9'].cells['3'].remove();
 	document.getElementById("tabla_competencias").rows['10'].cells['3'].remove();
    document.getElementById("tabla_competencias").rows['11'].cells['3'].remove();
 	document.getElementById("tabla_competencias").rows['12'].cells['3'].remove();
    document.getElementById("tabla_competencias").rows['13'].cells['3'].remove();
 	document.getElementById("tabla_competencias").rows['14'].cells['2'].remove();
    document.getElementById("tabla_competencias").rows['15'].cells['2'].remove();

	    }});

	});











document.getElementById("enviar_notas_admin").addEventListener("click",function(e){
	e.preventDefault();
	var mediciones = new Array();
	mediciones[0]=$('input[name="1"]:checked').val();
	mediciones[1]=$('input[name="2"]:checked').val();
	mediciones[2]=$('input[name="3"]:checked').val();
	mediciones[3]=$('input[name="4"]:checked').val();
	mediciones[4]=$('input[name="5"]:checked').val();
	mediciones[5]=$('input[name="6"]:checked').val();
	mediciones[6]=$('input[name="7"]:checked').val();
	mediciones[7]=$('input[name="8"]:checked').val();
	mediciones[8]=$('input[name="9"]:checked').val();
	for (var i = 0; i < mediciones.length; i++) {
		if (mediciones[i]==undefined) {
			comprueba=false;
			alert("Rellena todos los campos")
			$("#enviar_notas_admin").css("background","red")
			$("#enviar_notas_admin").css("color","white")
			break;
		}
		else{
			comprueba=true;
		}

	}

if (comprueba==true) {
	    $.post({url: base_url+"Evaluacion/obtener_notas_profe",
	        datatype:"json",
	        data:{'ID_Reto':document.getElementById('reto').value,'ID_Usuario':$("#select_alumnos").val(),'Nota':mediciones},
	        success: function(devuelto){
	        var array=JSON.parse(devuelto);

	        alert(devuelto)
	    }});
}
});