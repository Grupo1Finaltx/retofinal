	var base_url="http://localhost/CodeIgniter/index.php/";

	document.getElementById('b_centros').addEventListener('click',function(){
		location.href=base+"centro";
	});

	document.getElementById('b_ciclos').addEventListener('click',function(){
		location.href=base+"ciclo";
	});

	document.getElementById('b_cursos').addEventListener('click',function(){
		location.href=base+"curso";
	});

	document.getElementById('b_modulos').addEventListener('click',function(){
		location.href=base+"modulo";
	});

	document.getElementById('b_tipo_usu').addEventListener('click',function(){
		location.href=base+"tusuario";
	});

	document.getElementById('b_usuarios').addEventListener('click',function(){
		location.href=base+"usuario";
	});

	document.getElementById('b_usu_modulo').addEventListener('click',function(){
		location.href=base+"usuario_modulo";
	});

	document.getElementById('b_retos').addEventListener('click',function(){
		location.href=base+"reto";
	});

	document.getElementById('b_modulo_reto').addEventListener('click',function(){
		location.href=base+"reto_modulo";
	});

	document.getElementById('b_equipos').addEventListener('click',function(){
		location.href=base+"equipo";
	});

	document.getElementById('b_usu_equipo').addEventListener('click',function(){
		location.href=base+"equipo_usuario";
	});