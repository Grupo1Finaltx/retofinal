/* VARIABLE GLOBAL QUE GUARDA LA RUTA BASE DEL PROYECTO */
 var base_url="http://localhost/CodeIgniter/index.php/";


// AJAX PANEL PROFESOR
	$("#select_equipo").change(function(){
		$("#select_alumnos option").remove();
		$("#select_alumnos").append("<option>Selecciona alumno</option>");
	    $.post({url: base_url+"Evaluacion/alumnos_grupo_json",
	        datatype:"json",
	        data:{'ID_Equipo':$("#select_equipo").val()},
	        success: function(devuelto){
	        var array=JSON.parse(devuelto);
	        for (var i = 0; i < array.length; i++) {
	            $("#select_alumnos").append("<option value="+array[i]['ID_Usuario']+">"+array[i]['Nombre']+"</option>")
	        }
	    

	    }});
	});

/*---------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------*/

// en la tabla cursos para seleccionar todos con el checkbox

var veces=1;

$("#select_all").change(function(){

	if (veces>0) {
		$(":checkbox").attr('checked', true);
		veces--;
	}
	else{
		$(":checkbox").attr('checked', false);
		veces++;
	}
});


/*---------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------*/



/* Cuando se cambie el tamaño de la pantalla mostrara u ocultara el menu */
	window.addEventListener("resize",function(){
		if (innerWidth>767) {
			document.getElementById("div_derecha").style.display="inline-flex";

		}
		else{
			document.getElementById("div_derecha").style.display="none";
			menu=false;
			$("#aviso_mayus").css("display","none")
		}
});


/* Al hacer click en el boton desplegara el menu(solo movil) */
var menu=false;
document.getElementById("boton_menu").addEventListener("click", function(){
	menu=!menu;
	if (menu) {
		document.getElementById("div_derecha").style.display="block";
	}
	else{
		document.getElementById("div_derecha").style.display="none";		
	}

});





/*---------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------*/

// al cargar la pagina si existe la variable de localstorage rellenara el formulario de login
// esta variable habra se elimina al cerrar la sesion
window.onload = function() {rellenar_login()};

function rellenar_login(){

	if (localStorage.usuario) {
		document.getElementById('User').value=localStorage.usuario;
		document.getElementById('pass_login').value=localStorage.contrasena;
	}
}

/* Al enviar el formulario de inicio de sesion comprueba si se ha elegido
guardar el usuario, en ese caso lo guarda */
document.getElementById("iniciarsesion").addEventListener('click',function(){

if (document.getElementById('guardar_usuario').checked) {
localStorage.setItem("usuario",document.getElementById('User').value);
localStorage.setItem("contrasena",document.getElementById('pass_login').value);
}

});


// al clickar checbox muestra el tic personalizado
document.getElementById('guardar_usuario').addEventListener("click",function(){
	$(".nepecillo").css("display","block");
})

// al clicar en el tic personalizado oculta y deschequea checbox
$(".nepecillo").click(function(){
	$(".nepecillo").css("display","none");
	$("#guardar_usuario").prop('checked', false);
});


/*---------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------*/



// Esta funcion utiliza AJAX para controlar si el usuario que se esta introduciendo es correcto
	$('#User').keyup(function(){

	$("#User").css("background","#ff6666");

	$.post({url: base_url+"Index/usuario_json",
		        datatype:"json",
		        data:{'User':$("#User").val()},
		        success: function(devuelto){
		        var array=JSON.parse(devuelto);
		        if ($("#User").val()==array) {
		        	$("#User").css("background","lightgreen");
		        }
	}});
});



/*---------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------
-----------------------------------------------------------------------*/



