<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_modulo extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');		
		$this->load->model('Usuario_modulo_model');
		$this->load->model('Usuario_model');
		$this->load->model('Modulo_model');
	}




//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------




	public function index()
	{
		if ($this->session->userdata('ID_TUsuario')!=1) {
			redirect("Index");
		}
		$datos['usuarios_modulo'] = $this->Usuario_modulo_model->obtener_usuarios_modulo();
		$datos['usuarios'] = $this->Usuario_model->obtener_usuarios();
		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('usuario_modulo/listar_usuario_modulo',$datos);
		$this->load->view('vistas_logueado/control_usuario_logueado');

		$this->load->view('usuario_modulo/nuevo_usuario_modulo',$datos);
		$this->load->view('footer');
	}



//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
	public function obtener_modulos_centro(){

	$idusuario=$this->input->post('ID_Usuario');
	$datos = $this->Usuario_modulo_model->obtener_modulos_centro($idusuario);

 	echo json_encode($datos->result());
	}


	public function nuevo_usuario_modulo(){
	$datos = array(
		'ID_Usuario' => $this->input->post('ID_Usuario'),
		'ID_Modulo' => $this->input->post('ID_Modulo'),
	);
	$this->Usuario_modulo_model->nuevo_usuario_modulo($datos);
	redirect('Usuario_modulo');
	}


	public function borrar(){
		$id = $this->uri->segment(3);
		$this->Usuario_modulo_model->borrar_usuario_modulo($id);
		redirect('Usuario_modulo');
	}

}