<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');	
		$this->load->library('email');
		$this->load->helper('email');	
		$this->load->model('Usuario_model');
		$this->load->model('Centro_model');
		$this->load->model('Tusuario_model');
	}




//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------




	public function index()
	{
		if ($this->session->userdata('ID_TUsuario')!=1) {
			redirect("Index");
		}
		$datos['usuarios'] = $this->Usuario_model->obtener_usuarios();
		$datos['centros'] = $this->Centro_model->obtener_centros();
		$datos['tusuarios'] = $this->Tusuario_model->obtener_tusuarios();
		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('usuario/listar_usuario',$datos);
		$this->load->view('vistas_logueado/control_usuario_logueado');

		$this->load->view('usuario/nuevo_usuario',$datos);
		$this->load->view('footer');
	}



//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------





public function usuarios_csv(){
	//$tipo = $_FILES['archivo']['type'];
 
	//$tamanio = $_FILES['archivo']['size'];
 
	$archivotmp = $_FILES['archivo']['tmp_name'];
 
	$lineas = file($archivotmp);
	$i=0;
 
	foreach ($lineas as $linea_num => $linea){ 

	   if($i != 0) { 

	    $datos = explode(",",$linea);
		$this->Usuario_model->usuarios_csv($datos);
	 		foreach ($datos as $key) {
	 			echo $key,',';
	 		}
	 			echo "<br>";

	   }

	   $i++;
	}
	redirect("Usuario");
}



public function nuevo_usuario(){
	$datos = array(
		'ID_Centro' => $this->input->post('ID_Centro'),
		'ID_TUsuario' => $this->input->post('ID_TUsuario'),
		'User' => $this->input->post('User'),
		'Password' => md5("12345abc"),
		'Nombre' => $this->input->post('Nombre'),
		'Apellidos' => $this->input->post('Apellidos'),
		'Email' => $this->input->post('Email'),
		'Dni' => $this->input->post('Dni'),
	);

	$this->Usuario_model->nuevo_usuario($datos);
	redirect('Usuario');
}







//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//-


public function editar(){
		$datos['segmento']=$this->uri->segment(3);

		// select de los datos de usuario
		$datos['usuario']=$this->Usuario_model->obtener_usuario($datos['segmento']);
		
		$datos['centros']=$this->Centro_model->obtener_centros();
		
		$datos['tusuarios']=$this->Tusuario_model->obtener_tusuarios();
		
		$this->load->view('vistas_logueado/control_usuario_logueado');

		
		$this->load->view('head');
		$this->load->view('vistas_logueado/admin/admin_header');
		$this->load->view('usuario/editar_usuario',$datos);
		$this->load->view('footer');
}



	public function actualizar(){


		$datos = array(
			'ID_Centro' => $this->input->post('ID_Centro'),
			'ID_TUsuario' => $this->input->post('ID_TUsuario'),
			'User' => $this->input->post('User'),
			'Password' => md5("12345abc"),
			'Nombre' => $this->input->post('Nombre'),
			'Apellidos' => $this->input->post('Apellidos'),
			'Email' => $this->input->post('Email'),
			'Dni' => $this->input->post('Dni'),
		);
		$id = $this->uri->segment(3);
		$this->Usuario_model->actualizar_usuario($id,$datos);
		redirect('Usuario');
	}



//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------



	public function borrar(){
		$id = $this->uri->segment(3);
		$this->Usuario_model->borrar_usuario($id);
		redirect('Usuario');
	}






	public function usuarios_centro_json(){
		$idcentro=$this->input->post('ID_Centro');
		$usuarios_por_centro=$this->Usuario_model->obtener_usuario_centro($idcentro);

		echo json_encode($usuarios_por_centro->result());
	}




	public function restablecer_pass_email(){
		$user= $this->input->post('user_rec');

		$datosuser=$this->Usuario_model->obtener_usuario_nombre($user);
		foreach ($datosuser->result() as $key) {
			$iduser=$key->ID_Usuario;
			$email=$key->Email;
		}
		//configuracion para gmail
		 $configGmail = array(
		 'protocol' => 'smtp',
		 'smtp_host' => 'ssl://smtp.gmail.com',
		 'smtp_port' => 465,
		 'smtp_user' => 'grupo1finaltx@gmail.com',
		 'smtp_pass' => '123456789Aa',
		 'mailtype' => 'html',
		 'charset' => 'utf-8',
		 'newline' => "\r\n"
		 );    
		 
		 //cargamos la configuración para enviar con gmail
		 $this->email->initialize($configGmail);
		 
		 $this->email->from('grupo1finaltx@gmail.com');
		 $this->email->to($email);
		 $this->email->subject('Recuperación contraseña DIL');
		 $this->email->message('<h2><a href="http://localhost/xamppDavid/RETORUBRICAS/codigoinicio/CodeIgniter/index.php/Index/recuperar/'.$iduser.'">Click aquí para recuperar contraseña.</a><h2>');
		 $this->email->send();
		 redirect('Index');
	}








	public function modificar_pass(){
		$idusu=$this->session->userdata('ID_Usuario');
		$pass=md5($this->input->post('pass_usu_nueva'));
		$this->Usuario_model->modificar_pass($idusu,$pass);
	}




	public function obtener_admin(){
		$idmodulo=$this->input->post('ID_Modulo');
		$datos=$this->Usuario_model->obtener_admin($idmodulo);
		echo json_encode($datos->result());
	}


}