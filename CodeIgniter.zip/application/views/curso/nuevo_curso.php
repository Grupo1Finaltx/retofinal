

<h2>Crear un curso</h2>
<?php
$form = array(
	'name' => 'form_curso',
	'id' =>'formulario_crear'

	);
$COD_Curso = array(
	'name' => 'COD_Curso',
	'placeholder' => 'Código de Curso',
	'maxlength' => 9,
	'size' => 20
	);
?>

	<?php echo form_open('Curso/nuevo_curso',$form);?>
	<?php echo form_label('Código de Curso: ','COD_Curso'); ?>
	<?php echo form_input($COD_Curso); ?>
	<br>
	<?php echo form_submit('Crear','Crear','class="btn_crear"'); ?>
	<?php echo form_close();?>
</section>