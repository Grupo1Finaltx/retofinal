<section id="section_admin">

<article class="article_admin">
	<p>Administración de centros de FP</p>
	<button id="b_centros" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Administración de ciclos formativos</p>
	<button id="b_ciclos" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Administración de cursos</p>
	<button id="b_cursos" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Administración de modulos</p>
	<button id="b_modulos" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Administración de tipos de usuarios</p>
	<button id="b_tipo_usu" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Administración de usuarios</p>
	<button id="b_usuarios" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Añadir usuario a un modulo</p>
	<button id="b_usu_modulo" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Administración de retos</p>
	<button id="b_retos" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Añadir un modulo a un reto</p>
	<button id="b_modulo_reto" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Administración de equipos</p>
	<button id="b_equipos" type="button">Gestionar</button>
</article>

<article class="article_admin">
	<p>Añadir usuarios a un equipo</p>
	<button id="b_usu_equipo" type="button">Gestionar</button>
</article>

</section>


