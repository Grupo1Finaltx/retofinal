<script>
	// OBJETOS JAVASCRIPT

var usuario = {
    nombre: "<?php echo $this->session->userdata('Nombre'); ?>",
    rol     : "<?php echo $this->session->userdata('DESC_TUsuario'); ?>",
    funcion : function() {
       return this.nombre + "(" + this.rol+")";
    } 
};
	document.getElementById("nombre_usuario").innerHTML=usuario.funcion();

</script>
