<body>
<header>
	<nav>
		<ul id="ul_index">
			<li class="principal activo"><a href="">DIL</a></li>
			<li id="li_botonmenu"><button type="button" id="boton_menu"><i class="fa fa-bars" style="font-size:24px"></i></button></li>
			<div id="div_derecha">
				<li><a href="<?php echo base_url(); ?>index.php/Evaluacion/profe_ver_notas" title="">Notas de alumnos</a></li>
				<li><a href="" title="" id="nombre_usuario"></a></li>
				<li><a id="cerrar_sesion" href="<?php echo base_url(); ?>index.php/Index/cerrar_sesion" title="">Cerrar Sesión</a></li>
			</div>
		</ul>
	</nav>
</header>