
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="<?php echo base_url() ?>index.php/reto" title="">Gestión de retos</a></li>		
		<li><a href="" title="">Editar reto</a></li>
	</ul>
</nav>
<article class="article_editar">
<h1>Editar Reto</h1>
<?php
$form = array(
	'name' => 'form_reto'
	);
$url = "'".base_url()."index.php/Reto'";
$js_cancel_button = 'onClick="location.href='.$url.'"';

$COD_Reto = array(
	'name' => 'COD_Reto',
	'value' => $retos->result()[0]->COD_Reto,
	'placeholder' => 'Código de Reto',
	'maxlength' => 10,
	'size' => 20
	);

$DESC_Reto = array(
	'name' => 'DESC_Reto',
	'value' => $retos->result()[0]->DESC_Reto,
	'placeholder' => 'Descripción de Reto',
	'maxlength' => 50,
	'size' => 20
	);
?>

	<?php echo form_open('Reto/actualizar/'.$retos->result()[0]->ID_Reto,$form);?>
	<?php echo form_label('Código de Reto: ','COD_Reto'); ?>
	<?php echo form_input($COD_Reto); ?>
	<br>
	<?php echo form_label('Descripción de Reto: ','DESC_Reto'); ?>
	<?php echo form_input($DESC_Reto); ?>
	<br>
	<?php echo form_submit('Guardar','Guardar','class="guardar_edicion"'); ?>
	<?php echo form_button('Cancelar','Cancelar','class="cancelar_edicion"'.$js_cancel_button); ?>
	<?php echo form_close();?>

</article>