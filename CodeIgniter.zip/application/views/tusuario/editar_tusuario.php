<?php
$form = array(
	'name' => 'form_tusuario'
	);
$url = "'".base_url()."index.php/Tusuario'";
$js_cancel_button = 'onClick="location.href='.$url.'"';
$DESC_TUsuario = array(
	'name' => 'DESC_TUsuario',
	'value' => $tusuarios->result()[0]->DESC_TUsuario,
	'placeholder' => 'Descripción de tipo de usuario',
	'maxlength' => 50,
	'size' => 20
	);
?>
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="<?php echo base_url() ?>index.php/tusuario" title="">Gestión de tipos de usuarios</a></li>
		<li><a href="#" title="">Editar tipo de usuario</a></li>
	</ul>
</nav>

<article class="article_editar">
<h1>Editar tipo de usuario</h1>
	<?php echo form_open('Tusuario/actualizar/'.$tusuarios->result()[0]->ID_TUsuario,$form);?>
	<?php echo form_label('Descripción de tipo de usuario: ','DESC_TUsuario'); ?>
	<?php echo form_input($DESC_TUsuario); ?>
	<br>
	<?php echo form_submit('Guardar','Guardar','class="guardar_edicion"'); ?>
	<?php echo form_button('Cancelar','Cancelar','class="cancelar_edicion"'.$js_cancel_button); ?>	
	<?php echo form_close();?>

</article>