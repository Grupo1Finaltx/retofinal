
<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="" title="">Gestión de tipos de usuarios</a></li>
	</ul>
</nav>

<section class="section_gestion">
<h1>Gestión de tipos de usuarios</h1>
<article class="articulo_tabla">


<?php
		if ($tusuarios){
			printf('<table>
				<thead>			
				<tr>
					<td>
						<label for="select_all"></label>
						<input id="select_all" type="checkbox">
					</td>
				');
			$primertusuario = $tusuarios->result()[0];
			foreach ($primertusuario as $key => $value) {
				printf('<th id="%s">
						<span>%s</span>
					</th>',$key,$key);
			}
			printf('<th>Acciones</th></tr>
			</thead>
			<tbody>');
			foreach ($tusuarios->result() as $tusuario) {
				printf('<tr>
					<th>
					<label for="select_%d"></label>
					<input id="select_%d" type="checkbox">
					</th>',$tusuario->ID_TUsuario,$tusuario->ID_TUsuario);
				foreach ($tusuario as $detalle) {
					printf('<td>
					<a href="tusuario/editar/%s">%s</a>
					</td>',$tusuario->ID_TUsuario,$detalle);
				}
				$url = "'tusuario/borrar/".$tusuario->ID_TUsuario."'"; 
				$url_editar = "'tusuario/editar/".$tusuario->ID_TUsuario."'"; 
				printf('<td><input type="button" class="btn_borrar" onclick="location.href=%s" value="Borrar">',$url);
				printf('<input type="button" class="btn_editar" onclick="location.href=%s" value="Editar"></td>',$url_editar);
				printf('</tr>');
			}	
			printf('</tbody></table>');
		}
		else{
				printf('No hay Registros');
		}
		?>		
</article>