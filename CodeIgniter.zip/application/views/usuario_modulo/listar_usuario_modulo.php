

<nav id="nav_ruta_admin">
	<ul id="ul_ruta_admin">
		<li><a href="<?php echo base_url() ?>index.php/Index/admin" title="">Inicio</a></li>
		<li><a href="" title="">Añadir usuarios a un modulo</a></li>
	</ul>
</nav>

<section class="section_gestion">
<h1>Añadir usuarios a un modulo</h1>
<article class="articulo_tabla">




	<table id="tabla_usuario_modulo" border="1">
		<thead>
		<tr>
			<th>ID Usuario Modulo</th>
			<th>ID/Datos Usuario</th> 
			<th>ID/Código Modulo</th>
			<th colspan="2">Acciones</th>
		</tr>
		</thead>
		<tbody>

<?php 

if ($usuarios_modulo) {
	foreach ($usuarios_modulo->result() as $key) {
		echo '<tr>';
		echo '<td>'.$key->ID_Usuario_Modulo.'</td>';
		echo '<td>'.$key->ID_Usuario.' - '.$key->Nombre.' '.$key->Apellidos.'</td>';
		echo '<td>'.$key->ID_Modulo.' - '.$key->COD_Modulo.'</td>';
		$urleliminar = "'usuario_modulo/borrar/".$key->ID_Usuario_Modulo."'"; 
		printf('<td ><input type="button" class="btn_borrar btn_borrar_solo" onclick="location.href=%s" value="Borrar"></td>',$urleliminar);
		echo '</tr>';
	}
}

 ?>
		</tbody>
	</table>

</article>

<hr>