
<!-- EN ESTA PAGINA SE CREA UN FORMULARIO QUE LLAMARA A LA FUNCION comprobar_login EN EL CONTROLADOR Index.
	- Mientras se vaya escribiendo el usuario se ira comporbando mediante AJAX si el usuario es correcto
	  -->

<article id="ayuda_login_article">
	<p>Recibiras un correo electronico</p>
	<?php echo form_open('Usuario/restablecer_pass_email');?>
	<input type="text" name="user_rec" placeholder="Introduce tu usuario">
	<input type="submit" name="" value="Enviar">
	<input type="button" name="" id="cancela_ayuda_login" value="Cancelar">
	<?php echo form_close(); ?>
</article>

<section id="section_login">
	<h1>Iniciar Sesión en la aplicación</h1>

<?php 


$form = array(
	'name' => 'form_login',
	'id'   => 'form_login'
	);
$usuario = array(
	'name' => 'User',
	'placeholder' => 'Usuario*',
	'id' => 'User',
	'maxlength' => 15,
	'required' => 1
	);

$password = array(
	'name' => 'Password',
	'placeholder' => 'Contraseña*',
	'maxlength' => 15,
	'required' => 1,
	'id' => 'pass_login',
	);

$checkbox = array(
        'name'          => 'guardar_usuario',
        'id'            => 'guardar_usuario',
        'value'         => 'guardar_usuario',
        'checked'       => FALSE,
);



$submit = array(
        'id' => 'iniciarsesion',
);

?>




	<p id="aviso_mayus">*Tienes las mayúsculas activadas.</p>


	<?php echo form_open('Index/comprobar_login',$form);?>
	<div class="grupo_botones">
		<i class="material-icons">person</i>
		<?php echo form_input($usuario); ?>
	</div>	

	<div class="grupo_botones">
		<i class="material-icons">lock_outline</i>
		<?php echo form_password($password); ?>
	</div>
	<div class="grupo_recordar">
		<?php echo form_checkbox($checkbox); ?>
		<img class="nepecillo" src="../imagenes/tic_azul.png" alt=""><p>Recordar usuario</p>

	</div>
			<p>He olvidado mi contraseña<i class="material-icons" id="ayuda_login">help</i></p>


	<?php echo form_submit('iniciarsesion','Iniciar Sesión',$submit); 
	echo form_close();?>

 </section>

<?php 
	if ($cookie=="no") {
		echo "<div class='trampa'>?</div>";
	}
 ?>

 <div class="alerta">
 	<div class="circulo">
 <div class="check_caja">
    <div class="raya"></div>
    <div class="raya2"></div>
</div>

 	</div>
 	<p class="mensaje">Esta página web utiliza Cookies, si continuas navegando asumiremos que aceptas el uso.</p>
 	<button type="button" class="btn_alerta">Aceptar</button>

 </div>